using System.Diagnostics;

namespace battleshipp
{
    
    public partial class Form1 : Form
    {
        
        List<Button> playersPositionButtons;
        List<Button> enemyPositionButtons;

        Random random = new Random();
        int totalShip = 14;
        int round = 100;
        int playerScore;
        int enemyScore;
        public Form1()
        {
            InitializeComponent();
            RestartGame();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (playersPositionButtons.Count > 0 && round > 0)
            {
                round--;
                label48.Text = "Round: " + round;
                int index = random.Next(playersPositionButtons.Count);
                if ((string)playersPositionButtons[index].Tag == "playerShip")
                {
                    playersPositionButtons[index].BackgroundImage = Properties.Resources.x;
                    label45.Text = playersPositionButtons[index].Text;
                    playersPositionButtons[index].Enabled = false;
                    playersPositionButtons[index].BackColor = Color.DarkBlue;
                    playersPositionButtons.RemoveAt(index);
                    enemyScore++;
                    label47.Text = enemyScore.ToString();                  
                    timer1.Stop();
                }
                else
                {
                    playersPositionButtons[index].BackgroundImage = Properties.Resources.dash;
                    label45.Text = playersPositionButtons[index].Text;
                    playersPositionButtons[index].Enabled = false;
                    playersPositionButtons[index].BackColor = Color.DarkBlue;
                    playersPositionButtons.RemoveAt(index);
                    timer1.Stop();
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                var attackPosition = comboBox1.Text.ToLower();
                int index = enemyPositionButtons.FindIndex(a => a.Name == attackPosition);
                if (enemyPositionButtons[index].Enabled && round > 0)
                {
                    round--;
                    label45.Text = "Round:" + round;
                    if ((string)enemyPositionButtons[index].Tag == "enemyShip")
                    {
                        enemyPositionButtons[index].Enabled = false;
                        enemyPositionButtons[index].BackgroundImage = Properties.Resources.x;
                        enemyPositionButtons[index].BackColor = Color.DarkBlue;
                        playerScore++;
                        label46.Text = playerScore.ToString();
                        timer1.Start();
                    }
                    else
                    {
                        enemyPositionButtons[index].Enabled = false;
                        enemyPositionButtons[index].BackgroundImage = Properties.Resources.dash;
                        enemyPositionButtons[index].BackColor = Color.DarkBlue;
                        timer1.Start();
                    }
                }
            }
            else
            {
                MessageBox.Show("Choose a location from the drop down at first", "Information");
            }
        }
        int counter = 0;
        int counter1 = 0;
        int counter2 = 0;
        int counter3 = 0;
        private void d10_Click(object sender, EventArgs e)
        {
            
            if (counter < 5)
            {   
                var button = (Button)sender;
                button.Tag = "playerShip";
                button.BackColor = Color.LightPink;
                int x = button.Location.X;
                int y = button.Location.Y;  
                if(button!= null)
                {
                    button.Enabled = false;
                }
                foreach (Control c in Controls)
                {
                        
                        int xx = c.Location.X;
                        int yy = c.Location.Y;

                        if (c != button && xx != x && yy != y)
                        {
                            c.Enabled = false;
                            
                        }
                }
                 counter++;
           
                if (counter == 5)
                {
                    foreach (Control c in Controls)
                    {
                        c.Enabled = true;
                        button1.Enabled = true;
                        button1.BackColor = Color.Red;
                        button1.ForeColor = Color.White;
                        
                    }
                }
               
            }

            

            else if (counter1 < 4)
            {
                var button = (Button)sender;
                button.Tag = "playerShip";
                button.BackColor = Color.LightYellow;
                int x = button.Location.X;
                int y = button.Location.Y;
                if (button != null)
                {
                    button.Enabled = false;
                }
                foreach (Control c in Controls)
                {

                    int xx = c.Location.X;
                    int yy = c.Location.Y;

                    if (c != button && xx != x && yy != y)
                    {
                        c.Enabled = false;

                    }
                }
                counter1++;

                if (counter1 == 4)
                {
                    foreach (Control c in Controls)
                    {
                        c.Enabled = true;
                        button1.Enabled = true;
                        button1.BackColor = Color.Red;
                        button1.ForeColor = Color.White;
                    }
                }
                
            }

            else if (counter2 < 3)
            {
                var button = (Button)sender;
                button.Tag = "playerShip";
                button.BackColor = Color.LightCyan;
                int x = button.Location.X;
                int y = button.Location.Y;
                if (button != null)
                {
                    button.Enabled = false;
                }
                foreach (Control c in Controls)
                {

                    int xx = c.Location.X;
                    int yy = c.Location.Y;

                    if (c != button && xx != x && yy != y)
                    {
                        c.Enabled = false;

                    }
                }
                counter2++;

                if (counter2 == 3)
                {
                    foreach (Control c in Controls)
                    {
                        c.Enabled = true;
                        button1.Enabled = true;
                        button1.BackColor = Color.Red;
                        button1.ForeColor = Color.White;
                    }
                }

            }

            else if (counter3 < 2)
            {
                var button = (Button)sender;
                button.Tag = "playerShip";
                button.BackColor = Color.LightGreen;
                int x = button.Location.X;
                int y = button.Location.Y;
                if (button != null)
                {
                    button.Enabled = false;
                }
                foreach (Control c in Controls)
                {

                    int xx = c.Location.X;
                    int yy = c.Location.Y;

                    if (c != button && xx != x && yy != y)
                    {
                        c.Enabled = false;

                    }
                }
                counter3++;

                if (counter3 == 2)
                {
                    foreach (Control c in Controls)
                    {
                        c.Enabled = true;
                        button1.Enabled = true;
                        button1.BackColor = Color.Red;
                        button1.ForeColor = Color.White;
                    }
                }

            }
        }

        
        private void RestartGame()
        {
            playersPositionButtons = new List<Button> { a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,e1,e2,e3,e4,e5,e6,e7,e8,e8,e9,e10,f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,j1,j2,j3,j4,j5,j6,j7,j8,j9,j10 };
            enemyPositionButtons = new List<Button> { aa1, aa2, aa3, aa4, aa5, aa6, aa7, aa8, aa9, aa10, bb1, bb2, bb3, bb4, bb5, bb6, bb7, bb8, bb9, bb10, cc1, cc2, cc3, cc4, cc5, cc6, cc7, cc8, cc9, cc10, dd1, dd2, dd3, dd4, dd5, dd6, dd7, dd8, dd9, dd10, ee1, ee2, ee3, ee4, ee5, ee6, ee7, ee8, ee8, ee9, ee10, ff1, ff2, ff3, ff4, ff5, ff6, ff7, ff8, ff9, ff10, gg1, gg2, gg3, gg4, gg5, gg6, gg7, gg8, gg9, gg10, hh1, hh2, hh3, hh4, hh5, hh6, hh7, hh8, hh9, hh10, ii1, ii2, ii3, ii4, ii5, ii6, ii7, ii8, ii9, ii10, jj1, jj2, jj3, jj4, jj5, jj6, jj7, jj8, jj9, jj10 };
            comboBox1.Items.Clear();
            comboBox1.Text = null;
            for (int i = 0; i < playersPositionButtons.Count; i++)
            {
                enemyPositionButtons[i].Enabled = true;
                enemyPositionButtons[i].Tag = null;
                enemyPositionButtons[i].BackColor = Color.White;
                enemyPositionButtons[i].BackgroundImage = null;
                comboBox1.Items.Add(enemyPositionButtons[i].Text);
            }
            for (int i = 0; i < playersPositionButtons.Count; i++)
            {
                playersPositionButtons[i].Enabled = true;
                playersPositionButtons[i].Tag = null;
                playersPositionButtons[i].BackColor = Color.White;
                playersPositionButtons[i].BackgroundImage = null;
            }
            playerScore = 0;
            enemyScore = 0;
            round = 100;
            totalShip = 14;
            label46.Text = playerScore.ToString();
            label47.Text = enemyScore.ToString();
            label45.Text = "A1";
            button1.Enabled = false;
            enemyLocationPicker();
        }
        private void enemyLocationPicker()
        {
            for (int i = 0; i < 14; i++)
            {
                int index = random.Next(enemyPositionButtons.Count);
                if (enemyPositionButtons[index].Enabled == true && (string)enemyPositionButtons[index].Tag == null)
                {
                    enemyPositionButtons[index].Tag = "enemyShip";
                    Debug.WriteLine("Enemy Position: " + enemyPositionButtons[index].Text);
                }
                else
                {
                    index = random.Next(enemyPositionButtons.Count);
                }
            }
        }
        
        private void d10_MouseClick(object sender, MouseEventArgs e)
        {
            

        }
    }
}