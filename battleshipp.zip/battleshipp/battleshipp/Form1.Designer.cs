﻿namespace battleshipp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.a1 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.a10 = new System.Windows.Forms.Button();
            this.a9 = new System.Windows.Forms.Button();
            this.a8 = new System.Windows.Forms.Button();
            this.a7 = new System.Windows.Forms.Button();
            this.a6 = new System.Windows.Forms.Button();
            this.a5 = new System.Windows.Forms.Button();
            this.a4 = new System.Windows.Forms.Button();
            this.a3 = new System.Windows.Forms.Button();
            this.a2 = new System.Windows.Forms.Button();
            this.b10 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.c8 = new System.Windows.Forms.Button();
            this.c9 = new System.Windows.Forms.Button();
            this.c10 = new System.Windows.Forms.Button();
            this.c7 = new System.Windows.Forms.Button();
            this.c6 = new System.Windows.Forms.Button();
            this.c5 = new System.Windows.Forms.Button();
            this.c4 = new System.Windows.Forms.Button();
            this.c3 = new System.Windows.Forms.Button();
            this.c2 = new System.Windows.Forms.Button();
            this.c1 = new System.Windows.Forms.Button();
            this.d2 = new System.Windows.Forms.Button();
            this.d3 = new System.Windows.Forms.Button();
            this.d4 = new System.Windows.Forms.Button();
            this.d5 = new System.Windows.Forms.Button();
            this.d6 = new System.Windows.Forms.Button();
            this.d8 = new System.Windows.Forms.Button();
            this.d7 = new System.Windows.Forms.Button();
            this.d1 = new System.Windows.Forms.Button();
            this.h2 = new System.Windows.Forms.Button();
            this.g2 = new System.Windows.Forms.Button();
            this.f2 = new System.Windows.Forms.Button();
            this.e2 = new System.Windows.Forms.Button();
            this.j1 = new System.Windows.Forms.Button();
            this.i1 = new System.Windows.Forms.Button();
            this.h1 = new System.Windows.Forms.Button();
            this.g1 = new System.Windows.Forms.Button();
            this.f1 = new System.Windows.Forms.Button();
            this.e1 = new System.Windows.Forms.Button();
            this.f3 = new System.Windows.Forms.Button();
            this.e3 = new System.Windows.Forms.Button();
            this.j2 = new System.Windows.Forms.Button();
            this.i2 = new System.Windows.Forms.Button();
            this.h4 = new System.Windows.Forms.Button();
            this.g4 = new System.Windows.Forms.Button();
            this.f4 = new System.Windows.Forms.Button();
            this.e4 = new System.Windows.Forms.Button();
            this.j3 = new System.Windows.Forms.Button();
            this.i3 = new System.Windows.Forms.Button();
            this.h3 = new System.Windows.Forms.Button();
            this.g3 = new System.Windows.Forms.Button();
            this.h6 = new System.Windows.Forms.Button();
            this.g6 = new System.Windows.Forms.Button();
            this.f6 = new System.Windows.Forms.Button();
            this.e6 = new System.Windows.Forms.Button();
            this.j5 = new System.Windows.Forms.Button();
            this.i5 = new System.Windows.Forms.Button();
            this.h5 = new System.Windows.Forms.Button();
            this.g5 = new System.Windows.Forms.Button();
            this.f5 = new System.Windows.Forms.Button();
            this.e5 = new System.Windows.Forms.Button();
            this.j4 = new System.Windows.Forms.Button();
            this.i4 = new System.Windows.Forms.Button();
            this.i7 = new System.Windows.Forms.Button();
            this.h7 = new System.Windows.Forms.Button();
            this.g7 = new System.Windows.Forms.Button();
            this.f7 = new System.Windows.Forms.Button();
            this.e7 = new System.Windows.Forms.Button();
            this.j6 = new System.Windows.Forms.Button();
            this.i6 = new System.Windows.Forms.Button();
            this.j10 = new System.Windows.Forms.Button();
            this.j9 = new System.Windows.Forms.Button();
            this.j8 = new System.Windows.Forms.Button();
            this.i8 = new System.Windows.Forms.Button();
            this.h8 = new System.Windows.Forms.Button();
            this.g8 = new System.Windows.Forms.Button();
            this.f8 = new System.Windows.Forms.Button();
            this.e8 = new System.Windows.Forms.Button();
            this.j7 = new System.Windows.Forms.Button();
            this.f9 = new System.Windows.Forms.Button();
            this.g10 = new System.Windows.Forms.Button();
            this.g9 = new System.Windows.Forms.Button();
            this.h10 = new System.Windows.Forms.Button();
            this.h9 = new System.Windows.Forms.Button();
            this.i10 = new System.Windows.Forms.Button();
            this.i9 = new System.Windows.Forms.Button();
            this.d9 = new System.Windows.Forms.Button();
            this.f10 = new System.Windows.Forms.Button();
            this.e9 = new System.Windows.Forms.Button();
            this.e10 = new System.Windows.Forms.Button();
            this.d10 = new System.Windows.Forms.Button();
            this.dd10 = new System.Windows.Forms.Button();
            this.ee10 = new System.Windows.Forms.Button();
            this.ee9 = new System.Windows.Forms.Button();
            this.ff10 = new System.Windows.Forms.Button();
            this.dd9 = new System.Windows.Forms.Button();
            this.ii9 = new System.Windows.Forms.Button();
            this.ii10 = new System.Windows.Forms.Button();
            this.hh9 = new System.Windows.Forms.Button();
            this.hh10 = new System.Windows.Forms.Button();
            this.gg9 = new System.Windows.Forms.Button();
            this.gg10 = new System.Windows.Forms.Button();
            this.ff9 = new System.Windows.Forms.Button();
            this.jj7 = new System.Windows.Forms.Button();
            this.ee8 = new System.Windows.Forms.Button();
            this.ff8 = new System.Windows.Forms.Button();
            this.gg8 = new System.Windows.Forms.Button();
            this.hh8 = new System.Windows.Forms.Button();
            this.ii8 = new System.Windows.Forms.Button();
            this.jj8 = new System.Windows.Forms.Button();
            this.jj9 = new System.Windows.Forms.Button();
            this.jj10 = new System.Windows.Forms.Button();
            this.ii6 = new System.Windows.Forms.Button();
            this.jj6 = new System.Windows.Forms.Button();
            this.ee7 = new System.Windows.Forms.Button();
            this.ff7 = new System.Windows.Forms.Button();
            this.gg7 = new System.Windows.Forms.Button();
            this.hh7 = new System.Windows.Forms.Button();
            this.ii7 = new System.Windows.Forms.Button();
            this.ii4 = new System.Windows.Forms.Button();
            this.jj4 = new System.Windows.Forms.Button();
            this.ee5 = new System.Windows.Forms.Button();
            this.ff5 = new System.Windows.Forms.Button();
            this.gg5 = new System.Windows.Forms.Button();
            this.hh5 = new System.Windows.Forms.Button();
            this.ii5 = new System.Windows.Forms.Button();
            this.jj5 = new System.Windows.Forms.Button();
            this.ee6 = new System.Windows.Forms.Button();
            this.ff6 = new System.Windows.Forms.Button();
            this.gg6 = new System.Windows.Forms.Button();
            this.hh6 = new System.Windows.Forms.Button();
            this.gg3 = new System.Windows.Forms.Button();
            this.hh3 = new System.Windows.Forms.Button();
            this.ii3 = new System.Windows.Forms.Button();
            this.jj3 = new System.Windows.Forms.Button();
            this.ee4 = new System.Windows.Forms.Button();
            this.ff4 = new System.Windows.Forms.Button();
            this.gg4 = new System.Windows.Forms.Button();
            this.hh4 = new System.Windows.Forms.Button();
            this.ii2 = new System.Windows.Forms.Button();
            this.jj2 = new System.Windows.Forms.Button();
            this.ee3 = new System.Windows.Forms.Button();
            this.ff3 = new System.Windows.Forms.Button();
            this.ee1 = new System.Windows.Forms.Button();
            this.ff1 = new System.Windows.Forms.Button();
            this.gg1 = new System.Windows.Forms.Button();
            this.hh1 = new System.Windows.Forms.Button();
            this.ii1 = new System.Windows.Forms.Button();
            this.jj1 = new System.Windows.Forms.Button();
            this.ee2 = new System.Windows.Forms.Button();
            this.ff2 = new System.Windows.Forms.Button();
            this.gg2 = new System.Windows.Forms.Button();
            this.hh2 = new System.Windows.Forms.Button();
            this.dd1 = new System.Windows.Forms.Button();
            this.dd7 = new System.Windows.Forms.Button();
            this.dd8 = new System.Windows.Forms.Button();
            this.dd6 = new System.Windows.Forms.Button();
            this.dd5 = new System.Windows.Forms.Button();
            this.dd4 = new System.Windows.Forms.Button();
            this.dd3 = new System.Windows.Forms.Button();
            this.dd2 = new System.Windows.Forms.Button();
            this.cc1 = new System.Windows.Forms.Button();
            this.cc2 = new System.Windows.Forms.Button();
            this.cc3 = new System.Windows.Forms.Button();
            this.cc4 = new System.Windows.Forms.Button();
            this.cc5 = new System.Windows.Forms.Button();
            this.cc6 = new System.Windows.Forms.Button();
            this.cc7 = new System.Windows.Forms.Button();
            this.cc10 = new System.Windows.Forms.Button();
            this.cc9 = new System.Windows.Forms.Button();
            this.cc8 = new System.Windows.Forms.Button();
            this.bb4 = new System.Windows.Forms.Button();
            this.bb5 = new System.Windows.Forms.Button();
            this.bb6 = new System.Windows.Forms.Button();
            this.bb7 = new System.Windows.Forms.Button();
            this.bb8 = new System.Windows.Forms.Button();
            this.bb9 = new System.Windows.Forms.Button();
            this.bb10 = new System.Windows.Forms.Button();
            this.aa2 = new System.Windows.Forms.Button();
            this.aa3 = new System.Windows.Forms.Button();
            this.aa4 = new System.Windows.Forms.Button();
            this.aa5 = new System.Windows.Forms.Button();
            this.aa6 = new System.Windows.Forms.Button();
            this.aa7 = new System.Windows.Forms.Button();
            this.aa8 = new System.Windows.Forms.Button();
            this.aa9 = new System.Windows.Forms.Button();
            this.aa10 = new System.Windows.Forms.Button();
            this.bb2 = new System.Windows.Forms.Button();
            this.bb1 = new System.Windows.Forms.Button();
            this.bb3 = new System.Windows.Forms.Button();
            this.aa1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Move:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(309, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 46);
            this.label2.TabIndex = 1;
            this.label2.Text = "Player";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(1118, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 46);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enemy";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(914, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 33);
            this.label4.TabIndex = 3;
            this.label4.Text = "Enemy Move:";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(165, 15);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(107, 28);
            this.comboBox1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(290, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 29);
            this.button1.TabIndex = 5;
            this.button1.Text = "Attack";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // a1
            // 
            this.a1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a1.Location = new System.Drawing.Point(53, 163);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(58, 44);
            this.a1.TabIndex = 6;
            this.a1.Text = "A1";
            this.a1.UseVisualStyleBackColor = true;
            this.a1.Click += new System.EventHandler(this.d10_Click);
            this.a1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b3
            // 
            this.b3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b3.Location = new System.Drawing.Point(181, 213);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(58, 44);
            this.b3.TabIndex = 7;
            this.b3.Text = "B3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.d10_Click);
            this.b3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b1
            // 
            this.b1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b1.Location = new System.Drawing.Point(53, 213);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(58, 44);
            this.b1.TabIndex = 8;
            this.b1.Text = "B1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.d10_Click);
            this.b1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b2
            // 
            this.b2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b2.Location = new System.Drawing.Point(117, 213);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(58, 44);
            this.b2.TabIndex = 9;
            this.b2.Text = "B2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.d10_Click);
            this.b2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a10
            // 
            this.a10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a10.Location = new System.Drawing.Point(629, 163);
            this.a10.Name = "a10";
            this.a10.Size = new System.Drawing.Size(58, 44);
            this.a10.TabIndex = 10;
            this.a10.Text = "A10";
            this.a10.UseVisualStyleBackColor = true;
            this.a10.Click += new System.EventHandler(this.d10_Click);
            this.a10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a9
            // 
            this.a9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a9.Location = new System.Drawing.Point(565, 163);
            this.a9.Name = "a9";
            this.a9.Size = new System.Drawing.Size(58, 44);
            this.a9.TabIndex = 11;
            this.a9.Text = "A9";
            this.a9.UseVisualStyleBackColor = true;
            this.a9.Click += new System.EventHandler(this.d10_Click);
            this.a9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a8
            // 
            this.a8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a8.Location = new System.Drawing.Point(501, 163);
            this.a8.Name = "a8";
            this.a8.Size = new System.Drawing.Size(58, 44);
            this.a8.TabIndex = 12;
            this.a8.Text = "A8";
            this.a8.UseVisualStyleBackColor = true;
            this.a8.Click += new System.EventHandler(this.d10_Click);
            this.a8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a7
            // 
            this.a7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a7.Location = new System.Drawing.Point(437, 163);
            this.a7.Name = "a7";
            this.a7.Size = new System.Drawing.Size(58, 44);
            this.a7.TabIndex = 13;
            this.a7.Text = "A7";
            this.a7.UseVisualStyleBackColor = true;
            this.a7.Click += new System.EventHandler(this.d10_Click);
            this.a7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a6
            // 
            this.a6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a6.Location = new System.Drawing.Point(373, 163);
            this.a6.Name = "a6";
            this.a6.Size = new System.Drawing.Size(58, 44);
            this.a6.TabIndex = 14;
            this.a6.Text = "A6";
            this.a6.UseVisualStyleBackColor = true;
            this.a6.Click += new System.EventHandler(this.d10_Click);
            this.a6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a5
            // 
            this.a5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a5.Location = new System.Drawing.Point(309, 163);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(58, 44);
            this.a5.TabIndex = 15;
            this.a5.Text = "A5";
            this.a5.UseVisualStyleBackColor = true;
            this.a5.Click += new System.EventHandler(this.d10_Click);
            this.a5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a4
            // 
            this.a4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a4.Location = new System.Drawing.Point(245, 163);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(58, 44);
            this.a4.TabIndex = 16;
            this.a4.Text = "A4";
            this.a4.UseVisualStyleBackColor = true;
            this.a4.Click += new System.EventHandler(this.d10_Click);
            this.a4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a3
            // 
            this.a3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a3.Location = new System.Drawing.Point(181, 163);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(58, 44);
            this.a3.TabIndex = 17;
            this.a3.Text = "A3";
            this.a3.UseVisualStyleBackColor = true;
            this.a3.Click += new System.EventHandler(this.d10_Click);
            this.a3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // a2
            // 
            this.a2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.a2.Location = new System.Drawing.Point(117, 163);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(58, 44);
            this.a2.TabIndex = 18;
            this.a2.Text = "A2";
            this.a2.UseVisualStyleBackColor = true;
            this.a2.Click += new System.EventHandler(this.d10_Click);
            this.a2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b10
            // 
            this.b10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b10.Location = new System.Drawing.Point(629, 213);
            this.b10.Name = "b10";
            this.b10.Size = new System.Drawing.Size(58, 44);
            this.b10.TabIndex = 19;
            this.b10.Text = "B10";
            this.b10.UseVisualStyleBackColor = true;
            this.b10.Click += new System.EventHandler(this.d10_Click);
            this.b10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b9
            // 
            this.b9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b9.Location = new System.Drawing.Point(565, 213);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(58, 44);
            this.b9.TabIndex = 20;
            this.b9.Text = "B9";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.d10_Click);
            this.b9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b8
            // 
            this.b8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b8.Location = new System.Drawing.Point(501, 213);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(58, 44);
            this.b8.TabIndex = 21;
            this.b8.Text = "B8";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.d10_Click);
            this.b8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b7
            // 
            this.b7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b7.Location = new System.Drawing.Point(437, 213);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(58, 44);
            this.b7.TabIndex = 22;
            this.b7.Text = "B7";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.d10_Click);
            this.b7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b6
            // 
            this.b6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b6.Location = new System.Drawing.Point(373, 213);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(58, 44);
            this.b6.TabIndex = 23;
            this.b6.Text = "B6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.d10_Click);
            this.b6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b5
            // 
            this.b5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b5.Location = new System.Drawing.Point(309, 213);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(58, 44);
            this.b5.TabIndex = 24;
            this.b5.Text = "B5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.d10_Click);
            this.b5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // b4
            // 
            this.b4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.b4.Location = new System.Drawing.Point(245, 213);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(58, 44);
            this.b4.TabIndex = 25;
            this.b4.Text = "B4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.d10_Click);
            this.b4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c8
            // 
            this.c8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c8.Location = new System.Drawing.Point(501, 263);
            this.c8.Name = "c8";
            this.c8.Size = new System.Drawing.Size(58, 44);
            this.c8.TabIndex = 26;
            this.c8.Text = "C8";
            this.c8.UseVisualStyleBackColor = true;
            this.c8.Click += new System.EventHandler(this.d10_Click);
            this.c8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c9
            // 
            this.c9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c9.Location = new System.Drawing.Point(565, 263);
            this.c9.Name = "c9";
            this.c9.Size = new System.Drawing.Size(58, 44);
            this.c9.TabIndex = 27;
            this.c9.Text = "C9";
            this.c9.UseVisualStyleBackColor = true;
            this.c9.Click += new System.EventHandler(this.d10_Click);
            this.c9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c10
            // 
            this.c10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c10.Location = new System.Drawing.Point(629, 263);
            this.c10.Name = "c10";
            this.c10.Size = new System.Drawing.Size(58, 44);
            this.c10.TabIndex = 28;
            this.c10.Text = "C10";
            this.c10.UseVisualStyleBackColor = true;
            this.c10.Click += new System.EventHandler(this.d10_Click);
            this.c10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c7
            // 
            this.c7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c7.Location = new System.Drawing.Point(437, 263);
            this.c7.Name = "c7";
            this.c7.Size = new System.Drawing.Size(58, 44);
            this.c7.TabIndex = 29;
            this.c7.Text = "C7";
            this.c7.UseVisualStyleBackColor = true;
            this.c7.Click += new System.EventHandler(this.d10_Click);
            this.c7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c6
            // 
            this.c6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c6.Location = new System.Drawing.Point(373, 263);
            this.c6.Name = "c6";
            this.c6.Size = new System.Drawing.Size(58, 44);
            this.c6.TabIndex = 30;
            this.c6.Text = "C6";
            this.c6.UseVisualStyleBackColor = true;
            this.c6.Click += new System.EventHandler(this.d10_Click);
            this.c6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c5
            // 
            this.c5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c5.Location = new System.Drawing.Point(309, 263);
            this.c5.Name = "c5";
            this.c5.Size = new System.Drawing.Size(58, 44);
            this.c5.TabIndex = 31;
            this.c5.Text = "C5";
            this.c5.UseVisualStyleBackColor = true;
            this.c5.Click += new System.EventHandler(this.d10_Click);
            this.c5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c4
            // 
            this.c4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c4.Location = new System.Drawing.Point(245, 263);
            this.c4.Name = "c4";
            this.c4.Size = new System.Drawing.Size(58, 44);
            this.c4.TabIndex = 32;
            this.c4.Text = "C4";
            this.c4.UseVisualStyleBackColor = true;
            this.c4.Click += new System.EventHandler(this.d10_Click);
            this.c4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c3
            // 
            this.c3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c3.Location = new System.Drawing.Point(181, 263);
            this.c3.Name = "c3";
            this.c3.Size = new System.Drawing.Size(58, 44);
            this.c3.TabIndex = 33;
            this.c3.Text = "C3";
            this.c3.UseVisualStyleBackColor = true;
            this.c3.Click += new System.EventHandler(this.d10_Click);
            this.c3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c2
            // 
            this.c2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c2.Location = new System.Drawing.Point(117, 263);
            this.c2.Name = "c2";
            this.c2.Size = new System.Drawing.Size(58, 44);
            this.c2.TabIndex = 34;
            this.c2.Text = "C2";
            this.c2.UseVisualStyleBackColor = true;
            this.c2.Click += new System.EventHandler(this.d10_Click);
            this.c2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // c1
            // 
            this.c1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.c1.Location = new System.Drawing.Point(53, 263);
            this.c1.Name = "c1";
            this.c1.Size = new System.Drawing.Size(58, 44);
            this.c1.TabIndex = 35;
            this.c1.Text = "C1";
            this.c1.UseVisualStyleBackColor = true;
            this.c1.Click += new System.EventHandler(this.d10_Click);
            this.c1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d2
            // 
            this.d2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d2.Location = new System.Drawing.Point(117, 313);
            this.d2.Name = "d2";
            this.d2.Size = new System.Drawing.Size(58, 44);
            this.d2.TabIndex = 36;
            this.d2.Text = "D2";
            this.d2.UseVisualStyleBackColor = true;
            this.d2.Click += new System.EventHandler(this.d10_Click);
            this.d2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d3
            // 
            this.d3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d3.Location = new System.Drawing.Point(181, 313);
            this.d3.Name = "d3";
            this.d3.Size = new System.Drawing.Size(58, 44);
            this.d3.TabIndex = 37;
            this.d3.Text = "D3";
            this.d3.UseVisualStyleBackColor = true;
            this.d3.Click += new System.EventHandler(this.d10_Click);
            this.d3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d4
            // 
            this.d4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d4.Location = new System.Drawing.Point(245, 313);
            this.d4.Name = "d4";
            this.d4.Size = new System.Drawing.Size(58, 44);
            this.d4.TabIndex = 38;
            this.d4.Text = "D4";
            this.d4.UseVisualStyleBackColor = true;
            this.d4.Click += new System.EventHandler(this.d10_Click);
            this.d4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d5
            // 
            this.d5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d5.Location = new System.Drawing.Point(309, 313);
            this.d5.Name = "d5";
            this.d5.Size = new System.Drawing.Size(58, 44);
            this.d5.TabIndex = 39;
            this.d5.Text = "D5";
            this.d5.UseVisualStyleBackColor = true;
            this.d5.Click += new System.EventHandler(this.d10_Click);
            this.d5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d6
            // 
            this.d6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d6.Location = new System.Drawing.Point(373, 313);
            this.d6.Name = "d6";
            this.d6.Size = new System.Drawing.Size(58, 44);
            this.d6.TabIndex = 40;
            this.d6.Text = "D6";
            this.d6.UseVisualStyleBackColor = true;
            this.d6.Click += new System.EventHandler(this.d10_Click);
            this.d6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d8
            // 
            this.d8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d8.Location = new System.Drawing.Point(501, 313);
            this.d8.Name = "d8";
            this.d8.Size = new System.Drawing.Size(58, 44);
            this.d8.TabIndex = 41;
            this.d8.Text = "D8";
            this.d8.UseVisualStyleBackColor = true;
            this.d8.Click += new System.EventHandler(this.d10_Click);
            this.d8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d7
            // 
            this.d7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d7.Location = new System.Drawing.Point(437, 313);
            this.d7.Name = "d7";
            this.d7.Size = new System.Drawing.Size(58, 44);
            this.d7.TabIndex = 42;
            this.d7.Text = "D7";
            this.d7.UseVisualStyleBackColor = true;
            this.d7.Click += new System.EventHandler(this.d10_Click);
            this.d7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d1
            // 
            this.d1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d1.Location = new System.Drawing.Point(53, 313);
            this.d1.Name = "d1";
            this.d1.Size = new System.Drawing.Size(58, 44);
            this.d1.TabIndex = 43;
            this.d1.Text = "D1";
            this.d1.UseVisualStyleBackColor = true;
            this.d1.Click += new System.EventHandler(this.d10_Click);
            this.d1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h2
            // 
            this.h2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h2.Location = new System.Drawing.Point(117, 513);
            this.h2.Name = "h2";
            this.h2.Size = new System.Drawing.Size(58, 44);
            this.h2.TabIndex = 44;
            this.h2.Text = "H2";
            this.h2.UseVisualStyleBackColor = true;
            this.h2.Click += new System.EventHandler(this.d10_Click);
            this.h2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g2
            // 
            this.g2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g2.Location = new System.Drawing.Point(117, 463);
            this.g2.Name = "g2";
            this.g2.Size = new System.Drawing.Size(58, 44);
            this.g2.TabIndex = 45;
            this.g2.Text = "G2";
            this.g2.UseVisualStyleBackColor = true;
            this.g2.Click += new System.EventHandler(this.d10_Click);
            this.g2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f2
            // 
            this.f2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f2.Location = new System.Drawing.Point(117, 413);
            this.f2.Name = "f2";
            this.f2.Size = new System.Drawing.Size(58, 44);
            this.f2.TabIndex = 46;
            this.f2.Text = "F2";
            this.f2.UseVisualStyleBackColor = true;
            this.f2.Click += new System.EventHandler(this.d10_Click);
            this.f2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e2
            // 
            this.e2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e2.Location = new System.Drawing.Point(117, 363);
            this.e2.Name = "e2";
            this.e2.Size = new System.Drawing.Size(58, 44);
            this.e2.TabIndex = 47;
            this.e2.Text = "E2";
            this.e2.UseVisualStyleBackColor = true;
            this.e2.Click += new System.EventHandler(this.d10_Click);
            this.e2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j1
            // 
            this.j1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j1.Location = new System.Drawing.Point(53, 613);
            this.j1.Name = "j1";
            this.j1.Size = new System.Drawing.Size(58, 44);
            this.j1.TabIndex = 48;
            this.j1.Text = "J1";
            this.j1.UseVisualStyleBackColor = true;
            this.j1.Click += new System.EventHandler(this.d10_Click);
            this.j1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i1
            // 
            this.i1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i1.Location = new System.Drawing.Point(53, 563);
            this.i1.Name = "i1";
            this.i1.Size = new System.Drawing.Size(58, 44);
            this.i1.TabIndex = 49;
            this.i1.Text = "I1";
            this.i1.UseVisualStyleBackColor = true;
            this.i1.Click += new System.EventHandler(this.d10_Click);
            this.i1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h1
            // 
            this.h1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h1.Location = new System.Drawing.Point(53, 513);
            this.h1.Name = "h1";
            this.h1.Size = new System.Drawing.Size(58, 44);
            this.h1.TabIndex = 50;
            this.h1.Text = "H1";
            this.h1.UseVisualStyleBackColor = true;
            this.h1.Click += new System.EventHandler(this.d10_Click);
            this.h1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g1
            // 
            this.g1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g1.Location = new System.Drawing.Point(53, 463);
            this.g1.Name = "g1";
            this.g1.Size = new System.Drawing.Size(58, 44);
            this.g1.TabIndex = 51;
            this.g1.Text = "G1";
            this.g1.UseVisualStyleBackColor = true;
            this.g1.Click += new System.EventHandler(this.d10_Click);
            this.g1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f1
            // 
            this.f1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f1.Location = new System.Drawing.Point(53, 413);
            this.f1.Name = "f1";
            this.f1.Size = new System.Drawing.Size(58, 44);
            this.f1.TabIndex = 52;
            this.f1.Text = "F1";
            this.f1.UseVisualStyleBackColor = true;
            this.f1.Click += new System.EventHandler(this.d10_Click);
            this.f1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e1
            // 
            this.e1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e1.Location = new System.Drawing.Point(53, 363);
            this.e1.Name = "e1";
            this.e1.Size = new System.Drawing.Size(58, 44);
            this.e1.TabIndex = 53;
            this.e1.Text = "E1";
            this.e1.UseVisualStyleBackColor = true;
            this.e1.Click += new System.EventHandler(this.d10_Click);
            this.e1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f3
            // 
            this.f3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f3.Location = new System.Drawing.Point(181, 413);
            this.f3.Name = "f3";
            this.f3.Size = new System.Drawing.Size(58, 44);
            this.f3.TabIndex = 54;
            this.f3.Text = "F3";
            this.f3.UseVisualStyleBackColor = true;
            this.f3.Click += new System.EventHandler(this.d10_Click);
            this.f3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e3
            // 
            this.e3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e3.Location = new System.Drawing.Point(181, 363);
            this.e3.Name = "e3";
            this.e3.Size = new System.Drawing.Size(58, 44);
            this.e3.TabIndex = 55;
            this.e3.Text = "E3";
            this.e3.UseVisualStyleBackColor = true;
            this.e3.Click += new System.EventHandler(this.d10_Click);
            this.e3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j2
            // 
            this.j2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j2.Location = new System.Drawing.Point(117, 613);
            this.j2.Name = "j2";
            this.j2.Size = new System.Drawing.Size(58, 44);
            this.j2.TabIndex = 56;
            this.j2.Text = "J2";
            this.j2.UseVisualStyleBackColor = true;
            this.j2.Click += new System.EventHandler(this.d10_Click);
            this.j2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i2
            // 
            this.i2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i2.Location = new System.Drawing.Point(117, 563);
            this.i2.Name = "i2";
            this.i2.Size = new System.Drawing.Size(58, 44);
            this.i2.TabIndex = 57;
            this.i2.Text = "I2";
            this.i2.UseVisualStyleBackColor = true;
            this.i2.Click += new System.EventHandler(this.d10_Click);
            this.i2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h4
            // 
            this.h4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h4.Location = new System.Drawing.Point(245, 513);
            this.h4.Name = "h4";
            this.h4.Size = new System.Drawing.Size(58, 44);
            this.h4.TabIndex = 58;
            this.h4.Text = "H4";
            this.h4.UseVisualStyleBackColor = true;
            this.h4.Click += new System.EventHandler(this.d10_Click);
            this.h4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g4
            // 
            this.g4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g4.Location = new System.Drawing.Point(245, 463);
            this.g4.Name = "g4";
            this.g4.Size = new System.Drawing.Size(58, 44);
            this.g4.TabIndex = 59;
            this.g4.Text = "G4";
            this.g4.UseVisualStyleBackColor = true;
            this.g4.Click += new System.EventHandler(this.d10_Click);
            this.g4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f4
            // 
            this.f4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f4.Location = new System.Drawing.Point(245, 413);
            this.f4.Name = "f4";
            this.f4.Size = new System.Drawing.Size(58, 44);
            this.f4.TabIndex = 60;
            this.f4.Text = "F4";
            this.f4.UseVisualStyleBackColor = true;
            this.f4.Click += new System.EventHandler(this.d10_Click);
            this.f4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e4
            // 
            this.e4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e4.Location = new System.Drawing.Point(245, 363);
            this.e4.Name = "e4";
            this.e4.Size = new System.Drawing.Size(58, 44);
            this.e4.TabIndex = 61;
            this.e4.Text = "E4";
            this.e4.UseVisualStyleBackColor = true;
            this.e4.Click += new System.EventHandler(this.d10_Click);
            this.e4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j3
            // 
            this.j3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j3.Location = new System.Drawing.Point(181, 613);
            this.j3.Name = "j3";
            this.j3.Size = new System.Drawing.Size(58, 44);
            this.j3.TabIndex = 62;
            this.j3.Text = "J3";
            this.j3.UseVisualStyleBackColor = true;
            this.j3.Click += new System.EventHandler(this.d10_Click);
            this.j3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i3
            // 
            this.i3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i3.Location = new System.Drawing.Point(181, 563);
            this.i3.Name = "i3";
            this.i3.Size = new System.Drawing.Size(58, 44);
            this.i3.TabIndex = 63;
            this.i3.Text = "I3";
            this.i3.UseVisualStyleBackColor = true;
            this.i3.Click += new System.EventHandler(this.d10_Click);
            this.i3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h3
            // 
            this.h3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h3.Location = new System.Drawing.Point(181, 513);
            this.h3.Name = "h3";
            this.h3.Size = new System.Drawing.Size(58, 44);
            this.h3.TabIndex = 64;
            this.h3.Text = "H3";
            this.h3.UseVisualStyleBackColor = true;
            this.h3.Click += new System.EventHandler(this.d10_Click);
            this.h3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g3
            // 
            this.g3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g3.Location = new System.Drawing.Point(181, 463);
            this.g3.Name = "g3";
            this.g3.Size = new System.Drawing.Size(58, 44);
            this.g3.TabIndex = 65;
            this.g3.Text = "G3";
            this.g3.UseVisualStyleBackColor = true;
            this.g3.Click += new System.EventHandler(this.d10_Click);
            this.g3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h6
            // 
            this.h6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h6.Location = new System.Drawing.Point(373, 513);
            this.h6.Name = "h6";
            this.h6.Size = new System.Drawing.Size(58, 44);
            this.h6.TabIndex = 66;
            this.h6.Text = "H6";
            this.h6.UseVisualStyleBackColor = true;
            this.h6.Click += new System.EventHandler(this.d10_Click);
            this.h6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g6
            // 
            this.g6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g6.Location = new System.Drawing.Point(373, 463);
            this.g6.Name = "g6";
            this.g6.Size = new System.Drawing.Size(58, 44);
            this.g6.TabIndex = 67;
            this.g6.Text = "G6";
            this.g6.UseVisualStyleBackColor = true;
            this.g6.Click += new System.EventHandler(this.d10_Click);
            this.g6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f6
            // 
            this.f6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f6.Location = new System.Drawing.Point(373, 413);
            this.f6.Name = "f6";
            this.f6.Size = new System.Drawing.Size(58, 44);
            this.f6.TabIndex = 68;
            this.f6.Text = "F6";
            this.f6.UseVisualStyleBackColor = true;
            this.f6.Click += new System.EventHandler(this.d10_Click);
            this.f6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e6
            // 
            this.e6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e6.Location = new System.Drawing.Point(373, 363);
            this.e6.Name = "e6";
            this.e6.Size = new System.Drawing.Size(58, 44);
            this.e6.TabIndex = 69;
            this.e6.Text = "E6";
            this.e6.UseVisualStyleBackColor = true;
            this.e6.Click += new System.EventHandler(this.d10_Click);
            this.e6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j5
            // 
            this.j5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j5.Location = new System.Drawing.Point(309, 613);
            this.j5.Name = "j5";
            this.j5.Size = new System.Drawing.Size(58, 44);
            this.j5.TabIndex = 70;
            this.j5.Text = "J5";
            this.j5.UseVisualStyleBackColor = true;
            this.j5.Click += new System.EventHandler(this.d10_Click);
            this.j5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i5
            // 
            this.i5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i5.Location = new System.Drawing.Point(309, 563);
            this.i5.Name = "i5";
            this.i5.Size = new System.Drawing.Size(58, 44);
            this.i5.TabIndex = 71;
            this.i5.Text = "I5";
            this.i5.UseVisualStyleBackColor = true;
            this.i5.Click += new System.EventHandler(this.d10_Click);
            this.i5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h5
            // 
            this.h5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h5.Location = new System.Drawing.Point(309, 513);
            this.h5.Name = "h5";
            this.h5.Size = new System.Drawing.Size(58, 44);
            this.h5.TabIndex = 72;
            this.h5.Text = "H5";
            this.h5.UseVisualStyleBackColor = true;
            this.h5.Click += new System.EventHandler(this.d10_Click);
            this.h5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g5
            // 
            this.g5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g5.Location = new System.Drawing.Point(309, 463);
            this.g5.Name = "g5";
            this.g5.Size = new System.Drawing.Size(58, 44);
            this.g5.TabIndex = 73;
            this.g5.Text = "G5";
            this.g5.UseVisualStyleBackColor = true;
            this.g5.Click += new System.EventHandler(this.d10_Click);
            this.g5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f5
            // 
            this.f5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f5.Location = new System.Drawing.Point(309, 413);
            this.f5.Name = "f5";
            this.f5.Size = new System.Drawing.Size(58, 44);
            this.f5.TabIndex = 74;
            this.f5.Text = "F5";
            this.f5.UseVisualStyleBackColor = true;
            this.f5.Click += new System.EventHandler(this.d10_Click);
            this.f5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e5
            // 
            this.e5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e5.Location = new System.Drawing.Point(309, 363);
            this.e5.Name = "e5";
            this.e5.Size = new System.Drawing.Size(58, 44);
            this.e5.TabIndex = 75;
            this.e5.Text = "E5";
            this.e5.UseVisualStyleBackColor = true;
            this.e5.Click += new System.EventHandler(this.d10_Click);
            this.e5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j4
            // 
            this.j4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j4.Location = new System.Drawing.Point(245, 613);
            this.j4.Name = "j4";
            this.j4.Size = new System.Drawing.Size(58, 44);
            this.j4.TabIndex = 76;
            this.j4.Text = "J4";
            this.j4.UseVisualStyleBackColor = true;
            this.j4.Click += new System.EventHandler(this.d10_Click);
            this.j4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i4
            // 
            this.i4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i4.Location = new System.Drawing.Point(245, 563);
            this.i4.Name = "i4";
            this.i4.Size = new System.Drawing.Size(58, 44);
            this.i4.TabIndex = 77;
            this.i4.Text = "I4";
            this.i4.UseVisualStyleBackColor = true;
            this.i4.Click += new System.EventHandler(this.d10_Click);
            this.i4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i7
            // 
            this.i7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i7.Location = new System.Drawing.Point(437, 563);
            this.i7.Name = "i7";
            this.i7.Size = new System.Drawing.Size(58, 44);
            this.i7.TabIndex = 78;
            this.i7.Text = "I7";
            this.i7.UseVisualStyleBackColor = true;
            this.i7.Click += new System.EventHandler(this.d10_Click);
            this.i7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h7
            // 
            this.h7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h7.Location = new System.Drawing.Point(437, 513);
            this.h7.Name = "h7";
            this.h7.Size = new System.Drawing.Size(58, 44);
            this.h7.TabIndex = 79;
            this.h7.Text = "H7";
            this.h7.UseVisualStyleBackColor = true;
            this.h7.Click += new System.EventHandler(this.d10_Click);
            this.h7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g7
            // 
            this.g7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g7.Location = new System.Drawing.Point(437, 463);
            this.g7.Name = "g7";
            this.g7.Size = new System.Drawing.Size(58, 44);
            this.g7.TabIndex = 80;
            this.g7.Text = "G7";
            this.g7.UseVisualStyleBackColor = true;
            this.g7.Click += new System.EventHandler(this.d10_Click);
            this.g7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f7
            // 
            this.f7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f7.Location = new System.Drawing.Point(437, 413);
            this.f7.Name = "f7";
            this.f7.Size = new System.Drawing.Size(58, 44);
            this.f7.TabIndex = 81;
            this.f7.Text = "F7";
            this.f7.UseVisualStyleBackColor = true;
            this.f7.Click += new System.EventHandler(this.d10_Click);
            this.f7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e7
            // 
            this.e7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e7.Location = new System.Drawing.Point(437, 363);
            this.e7.Name = "e7";
            this.e7.Size = new System.Drawing.Size(58, 44);
            this.e7.TabIndex = 82;
            this.e7.Text = "E7";
            this.e7.UseVisualStyleBackColor = true;
            this.e7.Click += new System.EventHandler(this.d10_Click);
            this.e7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j6
            // 
            this.j6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j6.Location = new System.Drawing.Point(373, 613);
            this.j6.Name = "j6";
            this.j6.Size = new System.Drawing.Size(58, 44);
            this.j6.TabIndex = 83;
            this.j6.Text = "J6";
            this.j6.UseVisualStyleBackColor = true;
            this.j6.Click += new System.EventHandler(this.d10_Click);
            this.j6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i6
            // 
            this.i6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i6.Location = new System.Drawing.Point(373, 563);
            this.i6.Name = "i6";
            this.i6.Size = new System.Drawing.Size(58, 44);
            this.i6.TabIndex = 84;
            this.i6.Text = "I6";
            this.i6.UseVisualStyleBackColor = true;
            this.i6.Click += new System.EventHandler(this.d10_Click);
            this.i6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j10
            // 
            this.j10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j10.Location = new System.Drawing.Point(629, 613);
            this.j10.Name = "j10";
            this.j10.Size = new System.Drawing.Size(58, 44);
            this.j10.TabIndex = 85;
            this.j10.Text = "J10";
            this.j10.UseVisualStyleBackColor = true;
            this.j10.Click += new System.EventHandler(this.d10_Click);
            this.j10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j9
            // 
            this.j9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j9.Location = new System.Drawing.Point(565, 613);
            this.j9.Name = "j9";
            this.j9.Size = new System.Drawing.Size(58, 44);
            this.j9.TabIndex = 86;
            this.j9.Text = "J9";
            this.j9.UseVisualStyleBackColor = true;
            this.j9.Click += new System.EventHandler(this.d10_Click);
            this.j9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j8
            // 
            this.j8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j8.Location = new System.Drawing.Point(501, 613);
            this.j8.Name = "j8";
            this.j8.Size = new System.Drawing.Size(58, 44);
            this.j8.TabIndex = 87;
            this.j8.Text = "J8";
            this.j8.UseVisualStyleBackColor = true;
            this.j8.Click += new System.EventHandler(this.d10_Click);
            this.j8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i8
            // 
            this.i8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i8.Location = new System.Drawing.Point(501, 563);
            this.i8.Name = "i8";
            this.i8.Size = new System.Drawing.Size(58, 44);
            this.i8.TabIndex = 88;
            this.i8.Text = "I8";
            this.i8.UseVisualStyleBackColor = true;
            this.i8.Click += new System.EventHandler(this.d10_Click);
            this.i8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h8
            // 
            this.h8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h8.Location = new System.Drawing.Point(501, 513);
            this.h8.Name = "h8";
            this.h8.Size = new System.Drawing.Size(58, 44);
            this.h8.TabIndex = 89;
            this.h8.Text = "H8";
            this.h8.UseVisualStyleBackColor = true;
            this.h8.Click += new System.EventHandler(this.d10_Click);
            this.h8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g8
            // 
            this.g8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g8.Location = new System.Drawing.Point(501, 463);
            this.g8.Name = "g8";
            this.g8.Size = new System.Drawing.Size(58, 44);
            this.g8.TabIndex = 90;
            this.g8.Text = "G8";
            this.g8.UseVisualStyleBackColor = true;
            this.g8.Click += new System.EventHandler(this.d10_Click);
            this.g8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f8
            // 
            this.f8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f8.Location = new System.Drawing.Point(501, 413);
            this.f8.Name = "f8";
            this.f8.Size = new System.Drawing.Size(58, 44);
            this.f8.TabIndex = 91;
            this.f8.Text = "F8";
            this.f8.UseVisualStyleBackColor = true;
            this.f8.Click += new System.EventHandler(this.d10_Click);
            this.f8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e8
            // 
            this.e8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e8.Location = new System.Drawing.Point(501, 363);
            this.e8.Name = "e8";
            this.e8.Size = new System.Drawing.Size(58, 44);
            this.e8.TabIndex = 92;
            this.e8.Text = "E8";
            this.e8.UseVisualStyleBackColor = true;
            this.e8.Click += new System.EventHandler(this.d10_Click);
            this.e8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // j7
            // 
            this.j7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.j7.Location = new System.Drawing.Point(437, 613);
            this.j7.Name = "j7";
            this.j7.Size = new System.Drawing.Size(58, 44);
            this.j7.TabIndex = 93;
            this.j7.Text = "J7";
            this.j7.UseVisualStyleBackColor = true;
            this.j7.Click += new System.EventHandler(this.d10_Click);
            this.j7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f9
            // 
            this.f9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f9.Location = new System.Drawing.Point(565, 413);
            this.f9.Name = "f9";
            this.f9.Size = new System.Drawing.Size(58, 44);
            this.f9.TabIndex = 94;
            this.f9.Text = "F9";
            this.f9.UseVisualStyleBackColor = true;
            this.f9.Click += new System.EventHandler(this.d10_Click);
            this.f9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g10
            // 
            this.g10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g10.Location = new System.Drawing.Point(629, 463);
            this.g10.Name = "g10";
            this.g10.Size = new System.Drawing.Size(58, 44);
            this.g10.TabIndex = 95;
            this.g10.Text = "G10";
            this.g10.UseVisualStyleBackColor = true;
            this.g10.Click += new System.EventHandler(this.d10_Click);
            this.g10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // g9
            // 
            this.g9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.g9.Location = new System.Drawing.Point(565, 463);
            this.g9.Name = "g9";
            this.g9.Size = new System.Drawing.Size(58, 44);
            this.g9.TabIndex = 96;
            this.g9.Text = "G9";
            this.g9.UseVisualStyleBackColor = true;
            this.g9.Click += new System.EventHandler(this.d10_Click);
            this.g9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h10
            // 
            this.h10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h10.Location = new System.Drawing.Point(629, 513);
            this.h10.Name = "h10";
            this.h10.Size = new System.Drawing.Size(58, 44);
            this.h10.TabIndex = 97;
            this.h10.Text = "H10";
            this.h10.UseVisualStyleBackColor = true;
            this.h10.Click += new System.EventHandler(this.d10_Click);
            this.h10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // h9
            // 
            this.h9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.h9.Location = new System.Drawing.Point(565, 513);
            this.h9.Name = "h9";
            this.h9.Size = new System.Drawing.Size(58, 44);
            this.h9.TabIndex = 98;
            this.h9.Text = "H9";
            this.h9.UseVisualStyleBackColor = true;
            this.h9.Click += new System.EventHandler(this.d10_Click);
            this.h9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i10
            // 
            this.i10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i10.Location = new System.Drawing.Point(629, 563);
            this.i10.Name = "i10";
            this.i10.Size = new System.Drawing.Size(58, 44);
            this.i10.TabIndex = 99;
            this.i10.Text = "I10";
            this.i10.UseVisualStyleBackColor = true;
            this.i10.Click += new System.EventHandler(this.d10_Click);
            this.i10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // i9
            // 
            this.i9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.i9.Location = new System.Drawing.Point(565, 563);
            this.i9.Name = "i9";
            this.i9.Size = new System.Drawing.Size(58, 44);
            this.i9.TabIndex = 100;
            this.i9.Text = "I9";
            this.i9.UseVisualStyleBackColor = true;
            this.i9.Click += new System.EventHandler(this.d10_Click);
            this.i9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d9
            // 
            this.d9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d9.Location = new System.Drawing.Point(565, 313);
            this.d9.Name = "d9";
            this.d9.Size = new System.Drawing.Size(58, 44);
            this.d9.TabIndex = 101;
            this.d9.Text = "D9";
            this.d9.UseVisualStyleBackColor = true;
            this.d9.Click += new System.EventHandler(this.d10_Click);
            this.d9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // f10
            // 
            this.f10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.f10.Location = new System.Drawing.Point(629, 413);
            this.f10.Name = "f10";
            this.f10.Size = new System.Drawing.Size(58, 44);
            this.f10.TabIndex = 102;
            this.f10.Text = "F10";
            this.f10.UseVisualStyleBackColor = true;
            this.f10.Click += new System.EventHandler(this.d10_Click);
            this.f10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e9
            // 
            this.e9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e9.Location = new System.Drawing.Point(565, 363);
            this.e9.Name = "e9";
            this.e9.Size = new System.Drawing.Size(58, 44);
            this.e9.TabIndex = 104;
            this.e9.Text = "E9";
            this.e9.UseVisualStyleBackColor = true;
            this.e9.Click += new System.EventHandler(this.d10_Click);
            this.e9.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // e10
            // 
            this.e10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.e10.Location = new System.Drawing.Point(629, 363);
            this.e10.Name = "e10";
            this.e10.Size = new System.Drawing.Size(58, 44);
            this.e10.TabIndex = 105;
            this.e10.Text = "E10";
            this.e10.UseVisualStyleBackColor = true;
            this.e10.Click += new System.EventHandler(this.d10_Click);
            this.e10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // d10
            // 
            this.d10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.d10.Location = new System.Drawing.Point(629, 313);
            this.d10.Name = "d10";
            this.d10.Size = new System.Drawing.Size(58, 44);
            this.d10.TabIndex = 106;
            this.d10.Text = "D10";
            this.d10.UseVisualStyleBackColor = true;
            this.d10.Click += new System.EventHandler(this.d10_Click);
            this.d10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.d10_MouseClick);
            // 
            // dd10
            // 
            this.dd10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd10.Location = new System.Drawing.Point(1379, 313);
            this.dd10.Name = "dd10";
            this.dd10.Size = new System.Drawing.Size(58, 44);
            this.dd10.TabIndex = 206;
            this.dd10.Text = "DD10";
            this.dd10.UseVisualStyleBackColor = true;
            // 
            // ee10
            // 
            this.ee10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee10.Location = new System.Drawing.Point(1379, 363);
            this.ee10.Name = "ee10";
            this.ee10.Size = new System.Drawing.Size(58, 44);
            this.ee10.TabIndex = 205;
            this.ee10.Text = "EE10";
            this.ee10.UseVisualStyleBackColor = true;
            // 
            // ee9
            // 
            this.ee9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee9.Location = new System.Drawing.Point(1315, 363);
            this.ee9.Name = "ee9";
            this.ee9.Size = new System.Drawing.Size(58, 44);
            this.ee9.TabIndex = 204;
            this.ee9.Text = "EE9";
            this.ee9.UseVisualStyleBackColor = true;
            // 
            // ff10
            // 
            this.ff10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff10.Location = new System.Drawing.Point(1379, 413);
            this.ff10.Name = "ff10";
            this.ff10.Size = new System.Drawing.Size(58, 44);
            this.ff10.TabIndex = 203;
            this.ff10.Text = "FF10";
            this.ff10.UseVisualStyleBackColor = true;
            // 
            // dd9
            // 
            this.dd9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd9.Location = new System.Drawing.Point(1315, 313);
            this.dd9.Name = "dd9";
            this.dd9.Size = new System.Drawing.Size(58, 44);
            this.dd9.TabIndex = 202;
            this.dd9.Text = "DD9";
            this.dd9.UseVisualStyleBackColor = true;
            // 
            // ii9
            // 
            this.ii9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii9.Location = new System.Drawing.Point(1315, 563);
            this.ii9.Name = "ii9";
            this.ii9.Size = new System.Drawing.Size(58, 44);
            this.ii9.TabIndex = 201;
            this.ii9.Text = "II9";
            this.ii9.UseVisualStyleBackColor = true;
            // 
            // ii10
            // 
            this.ii10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii10.Location = new System.Drawing.Point(1379, 563);
            this.ii10.Name = "ii10";
            this.ii10.Size = new System.Drawing.Size(58, 44);
            this.ii10.TabIndex = 200;
            this.ii10.Text = "II10";
            this.ii10.UseVisualStyleBackColor = true;
            // 
            // hh9
            // 
            this.hh9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh9.Location = new System.Drawing.Point(1315, 513);
            this.hh9.Name = "hh9";
            this.hh9.Size = new System.Drawing.Size(58, 44);
            this.hh9.TabIndex = 199;
            this.hh9.Text = "HH9";
            this.hh9.UseVisualStyleBackColor = true;
            // 
            // hh10
            // 
            this.hh10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh10.Location = new System.Drawing.Point(1379, 513);
            this.hh10.Name = "hh10";
            this.hh10.Size = new System.Drawing.Size(58, 44);
            this.hh10.TabIndex = 198;
            this.hh10.Text = "HH10";
            this.hh10.UseVisualStyleBackColor = true;
            // 
            // gg9
            // 
            this.gg9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg9.Location = new System.Drawing.Point(1315, 463);
            this.gg9.Name = "gg9";
            this.gg9.Size = new System.Drawing.Size(58, 44);
            this.gg9.TabIndex = 197;
            this.gg9.Text = "GG9";
            this.gg9.UseVisualStyleBackColor = true;
            // 
            // gg10
            // 
            this.gg10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg10.Location = new System.Drawing.Point(1379, 463);
            this.gg10.Name = "gg10";
            this.gg10.Size = new System.Drawing.Size(58, 44);
            this.gg10.TabIndex = 196;
            this.gg10.Text = "GG10";
            this.gg10.UseVisualStyleBackColor = true;
            // 
            // ff9
            // 
            this.ff9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff9.Location = new System.Drawing.Point(1315, 413);
            this.ff9.Name = "ff9";
            this.ff9.Size = new System.Drawing.Size(58, 44);
            this.ff9.TabIndex = 195;
            this.ff9.Text = "FF9";
            this.ff9.UseVisualStyleBackColor = true;
            // 
            // jj7
            // 
            this.jj7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj7.Location = new System.Drawing.Point(1187, 613);
            this.jj7.Name = "jj7";
            this.jj7.Size = new System.Drawing.Size(58, 44);
            this.jj7.TabIndex = 194;
            this.jj7.Text = "JJ7";
            this.jj7.UseVisualStyleBackColor = true;
            // 
            // ee8
            // 
            this.ee8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee8.Location = new System.Drawing.Point(1251, 363);
            this.ee8.Name = "ee8";
            this.ee8.Size = new System.Drawing.Size(58, 44);
            this.ee8.TabIndex = 193;
            this.ee8.Text = "EE8";
            this.ee8.UseVisualStyleBackColor = true;
            // 
            // ff8
            // 
            this.ff8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff8.Location = new System.Drawing.Point(1251, 413);
            this.ff8.Name = "ff8";
            this.ff8.Size = new System.Drawing.Size(58, 44);
            this.ff8.TabIndex = 192;
            this.ff8.Text = "FF8";
            this.ff8.UseVisualStyleBackColor = true;
            // 
            // gg8
            // 
            this.gg8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg8.Location = new System.Drawing.Point(1251, 463);
            this.gg8.Name = "gg8";
            this.gg8.Size = new System.Drawing.Size(58, 44);
            this.gg8.TabIndex = 191;
            this.gg8.Text = "GG8";
            this.gg8.UseVisualStyleBackColor = true;
            // 
            // hh8
            // 
            this.hh8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh8.Location = new System.Drawing.Point(1251, 513);
            this.hh8.Name = "hh8";
            this.hh8.Size = new System.Drawing.Size(58, 44);
            this.hh8.TabIndex = 190;
            this.hh8.Text = "HH8";
            this.hh8.UseVisualStyleBackColor = true;
            // 
            // ii8
            // 
            this.ii8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii8.Location = new System.Drawing.Point(1251, 563);
            this.ii8.Name = "ii8";
            this.ii8.Size = new System.Drawing.Size(58, 44);
            this.ii8.TabIndex = 189;
            this.ii8.Text = "II8";
            this.ii8.UseVisualStyleBackColor = true;
            // 
            // jj8
            // 
            this.jj8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj8.Location = new System.Drawing.Point(1251, 613);
            this.jj8.Name = "jj8";
            this.jj8.Size = new System.Drawing.Size(58, 44);
            this.jj8.TabIndex = 188;
            this.jj8.Text = "JJ8";
            this.jj8.UseVisualStyleBackColor = true;
            // 
            // jj9
            // 
            this.jj9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj9.Location = new System.Drawing.Point(1315, 613);
            this.jj9.Name = "jj9";
            this.jj9.Size = new System.Drawing.Size(58, 44);
            this.jj9.TabIndex = 187;
            this.jj9.Text = "JJ9";
            this.jj9.UseVisualStyleBackColor = true;
            // 
            // jj10
            // 
            this.jj10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj10.Location = new System.Drawing.Point(1379, 613);
            this.jj10.Name = "jj10";
            this.jj10.Size = new System.Drawing.Size(58, 44);
            this.jj10.TabIndex = 186;
            this.jj10.Text = "JJ10";
            this.jj10.UseVisualStyleBackColor = true;
            // 
            // ii6
            // 
            this.ii6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii6.Location = new System.Drawing.Point(1123, 563);
            this.ii6.Name = "ii6";
            this.ii6.Size = new System.Drawing.Size(58, 44);
            this.ii6.TabIndex = 185;
            this.ii6.Text = "II6";
            this.ii6.UseVisualStyleBackColor = true;
            // 
            // jj6
            // 
            this.jj6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj6.Location = new System.Drawing.Point(1123, 613);
            this.jj6.Name = "jj6";
            this.jj6.Size = new System.Drawing.Size(58, 44);
            this.jj6.TabIndex = 184;
            this.jj6.Text = "JJ6";
            this.jj6.UseVisualStyleBackColor = true;
            // 
            // ee7
            // 
            this.ee7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee7.Location = new System.Drawing.Point(1187, 363);
            this.ee7.Name = "ee7";
            this.ee7.Size = new System.Drawing.Size(58, 44);
            this.ee7.TabIndex = 183;
            this.ee7.Text = "EE7";
            this.ee7.UseVisualStyleBackColor = true;
            // 
            // ff7
            // 
            this.ff7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff7.Location = new System.Drawing.Point(1187, 413);
            this.ff7.Name = "ff7";
            this.ff7.Size = new System.Drawing.Size(58, 44);
            this.ff7.TabIndex = 182;
            this.ff7.Text = "FF7";
            this.ff7.UseVisualStyleBackColor = true;
            // 
            // gg7
            // 
            this.gg7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg7.Location = new System.Drawing.Point(1187, 463);
            this.gg7.Name = "gg7";
            this.gg7.Size = new System.Drawing.Size(58, 44);
            this.gg7.TabIndex = 181;
            this.gg7.Text = "GG7";
            this.gg7.UseVisualStyleBackColor = true;
            // 
            // hh7
            // 
            this.hh7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh7.Location = new System.Drawing.Point(1187, 513);
            this.hh7.Name = "hh7";
            this.hh7.Size = new System.Drawing.Size(58, 44);
            this.hh7.TabIndex = 180;
            this.hh7.Text = "HH7";
            this.hh7.UseVisualStyleBackColor = true;
            // 
            // ii7
            // 
            this.ii7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii7.Location = new System.Drawing.Point(1187, 563);
            this.ii7.Name = "ii7";
            this.ii7.Size = new System.Drawing.Size(58, 44);
            this.ii7.TabIndex = 179;
            this.ii7.Text = "II7";
            this.ii7.UseVisualStyleBackColor = true;
            // 
            // ii4
            // 
            this.ii4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii4.Location = new System.Drawing.Point(995, 563);
            this.ii4.Name = "ii4";
            this.ii4.Size = new System.Drawing.Size(58, 44);
            this.ii4.TabIndex = 178;
            this.ii4.Text = "II4";
            this.ii4.UseVisualStyleBackColor = true;
            // 
            // jj4
            // 
            this.jj4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj4.Location = new System.Drawing.Point(995, 613);
            this.jj4.Name = "jj4";
            this.jj4.Size = new System.Drawing.Size(58, 44);
            this.jj4.TabIndex = 177;
            this.jj4.Text = "JJ4";
            this.jj4.UseVisualStyleBackColor = true;
            // 
            // ee5
            // 
            this.ee5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee5.Location = new System.Drawing.Point(1059, 363);
            this.ee5.Name = "ee5";
            this.ee5.Size = new System.Drawing.Size(58, 44);
            this.ee5.TabIndex = 176;
            this.ee5.Text = "EE5";
            this.ee5.UseVisualStyleBackColor = true;
            // 
            // ff5
            // 
            this.ff5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff5.Location = new System.Drawing.Point(1059, 413);
            this.ff5.Name = "ff5";
            this.ff5.Size = new System.Drawing.Size(58, 44);
            this.ff5.TabIndex = 175;
            this.ff5.Text = "FF5";
            this.ff5.UseVisualStyleBackColor = true;
            // 
            // gg5
            // 
            this.gg5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg5.Location = new System.Drawing.Point(1059, 463);
            this.gg5.Name = "gg5";
            this.gg5.Size = new System.Drawing.Size(58, 44);
            this.gg5.TabIndex = 174;
            this.gg5.Text = "GG5";
            this.gg5.UseVisualStyleBackColor = true;
            // 
            // hh5
            // 
            this.hh5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh5.Location = new System.Drawing.Point(1059, 513);
            this.hh5.Name = "hh5";
            this.hh5.Size = new System.Drawing.Size(58, 44);
            this.hh5.TabIndex = 173;
            this.hh5.Text = "HH5";
            this.hh5.UseVisualStyleBackColor = true;
            // 
            // ii5
            // 
            this.ii5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii5.Location = new System.Drawing.Point(1059, 563);
            this.ii5.Name = "ii5";
            this.ii5.Size = new System.Drawing.Size(58, 44);
            this.ii5.TabIndex = 172;
            this.ii5.Text = "II5";
            this.ii5.UseVisualStyleBackColor = true;
            // 
            // jj5
            // 
            this.jj5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj5.Location = new System.Drawing.Point(1059, 613);
            this.jj5.Name = "jj5";
            this.jj5.Size = new System.Drawing.Size(58, 44);
            this.jj5.TabIndex = 171;
            this.jj5.Text = "JJ5";
            this.jj5.UseVisualStyleBackColor = true;
            // 
            // ee6
            // 
            this.ee6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee6.Location = new System.Drawing.Point(1123, 363);
            this.ee6.Name = "ee6";
            this.ee6.Size = new System.Drawing.Size(58, 44);
            this.ee6.TabIndex = 170;
            this.ee6.Text = "EE6";
            this.ee6.UseVisualStyleBackColor = true;
            // 
            // ff6
            // 
            this.ff6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff6.Location = new System.Drawing.Point(1123, 413);
            this.ff6.Name = "ff6";
            this.ff6.Size = new System.Drawing.Size(58, 44);
            this.ff6.TabIndex = 169;
            this.ff6.Text = "FF6";
            this.ff6.UseVisualStyleBackColor = true;
            // 
            // gg6
            // 
            this.gg6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg6.Location = new System.Drawing.Point(1123, 463);
            this.gg6.Name = "gg6";
            this.gg6.Size = new System.Drawing.Size(58, 44);
            this.gg6.TabIndex = 168;
            this.gg6.Text = "GG6";
            this.gg6.UseVisualStyleBackColor = true;
            // 
            // hh6
            // 
            this.hh6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh6.Location = new System.Drawing.Point(1123, 513);
            this.hh6.Name = "hh6";
            this.hh6.Size = new System.Drawing.Size(58, 44);
            this.hh6.TabIndex = 167;
            this.hh6.Text = "HH6";
            this.hh6.UseVisualStyleBackColor = true;
            // 
            // gg3
            // 
            this.gg3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg3.Location = new System.Drawing.Point(931, 463);
            this.gg3.Name = "gg3";
            this.gg3.Size = new System.Drawing.Size(58, 44);
            this.gg3.TabIndex = 166;
            this.gg3.Text = "GG3";
            this.gg3.UseVisualStyleBackColor = true;
            // 
            // hh3
            // 
            this.hh3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh3.Location = new System.Drawing.Point(931, 513);
            this.hh3.Name = "hh3";
            this.hh3.Size = new System.Drawing.Size(58, 44);
            this.hh3.TabIndex = 165;
            this.hh3.Text = "HH3";
            this.hh3.UseVisualStyleBackColor = true;
            // 
            // ii3
            // 
            this.ii3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii3.Location = new System.Drawing.Point(931, 563);
            this.ii3.Name = "ii3";
            this.ii3.Size = new System.Drawing.Size(58, 44);
            this.ii3.TabIndex = 164;
            this.ii3.Text = "II3";
            this.ii3.UseVisualStyleBackColor = true;
            // 
            // jj3
            // 
            this.jj3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj3.Location = new System.Drawing.Point(931, 613);
            this.jj3.Name = "jj3";
            this.jj3.Size = new System.Drawing.Size(58, 44);
            this.jj3.TabIndex = 163;
            this.jj3.Text = "JJ3";
            this.jj3.UseVisualStyleBackColor = true;
            // 
            // ee4
            // 
            this.ee4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee4.Location = new System.Drawing.Point(995, 363);
            this.ee4.Name = "ee4";
            this.ee4.Size = new System.Drawing.Size(58, 44);
            this.ee4.TabIndex = 162;
            this.ee4.Text = "EE4";
            this.ee4.UseVisualStyleBackColor = true;
            // 
            // ff4
            // 
            this.ff4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff4.Location = new System.Drawing.Point(995, 413);
            this.ff4.Name = "ff4";
            this.ff4.Size = new System.Drawing.Size(58, 44);
            this.ff4.TabIndex = 161;
            this.ff4.Text = "FF4";
            this.ff4.UseVisualStyleBackColor = true;
            // 
            // gg4
            // 
            this.gg4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg4.Location = new System.Drawing.Point(995, 463);
            this.gg4.Name = "gg4";
            this.gg4.Size = new System.Drawing.Size(58, 44);
            this.gg4.TabIndex = 160;
            this.gg4.Text = "GG4";
            this.gg4.UseVisualStyleBackColor = true;
            // 
            // hh4
            // 
            this.hh4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh4.Location = new System.Drawing.Point(995, 513);
            this.hh4.Name = "hh4";
            this.hh4.Size = new System.Drawing.Size(58, 44);
            this.hh4.TabIndex = 159;
            this.hh4.Text = "HH4";
            this.hh4.UseVisualStyleBackColor = true;
            // 
            // ii2
            // 
            this.ii2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii2.Location = new System.Drawing.Point(867, 563);
            this.ii2.Name = "ii2";
            this.ii2.Size = new System.Drawing.Size(58, 44);
            this.ii2.TabIndex = 158;
            this.ii2.Text = "II2";
            this.ii2.UseVisualStyleBackColor = true;
            // 
            // jj2
            // 
            this.jj2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj2.Location = new System.Drawing.Point(867, 613);
            this.jj2.Name = "jj2";
            this.jj2.Size = new System.Drawing.Size(58, 44);
            this.jj2.TabIndex = 157;
            this.jj2.Text = "JJ2";
            this.jj2.UseVisualStyleBackColor = true;
            // 
            // ee3
            // 
            this.ee3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee3.Location = new System.Drawing.Point(931, 363);
            this.ee3.Name = "ee3";
            this.ee3.Size = new System.Drawing.Size(58, 44);
            this.ee3.TabIndex = 156;
            this.ee3.Text = "EE3";
            this.ee3.UseVisualStyleBackColor = true;
            // 
            // ff3
            // 
            this.ff3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff3.Location = new System.Drawing.Point(931, 413);
            this.ff3.Name = "ff3";
            this.ff3.Size = new System.Drawing.Size(58, 44);
            this.ff3.TabIndex = 155;
            this.ff3.Text = "FF3";
            this.ff3.UseVisualStyleBackColor = true;
            // 
            // ee1
            // 
            this.ee1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee1.Location = new System.Drawing.Point(803, 363);
            this.ee1.Name = "ee1";
            this.ee1.Size = new System.Drawing.Size(58, 44);
            this.ee1.TabIndex = 154;
            this.ee1.Text = "EE1";
            this.ee1.UseVisualStyleBackColor = true;
            // 
            // ff1
            // 
            this.ff1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff1.Location = new System.Drawing.Point(803, 413);
            this.ff1.Name = "ff1";
            this.ff1.Size = new System.Drawing.Size(58, 44);
            this.ff1.TabIndex = 153;
            this.ff1.Text = "FF1";
            this.ff1.UseVisualStyleBackColor = true;
            // 
            // gg1
            // 
            this.gg1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg1.Location = new System.Drawing.Point(803, 463);
            this.gg1.Name = "gg1";
            this.gg1.Size = new System.Drawing.Size(58, 44);
            this.gg1.TabIndex = 152;
            this.gg1.Text = "GG1";
            this.gg1.UseVisualStyleBackColor = true;
            // 
            // hh1
            // 
            this.hh1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh1.Location = new System.Drawing.Point(803, 513);
            this.hh1.Name = "hh1";
            this.hh1.Size = new System.Drawing.Size(58, 44);
            this.hh1.TabIndex = 151;
            this.hh1.Text = "HH1";
            this.hh1.UseVisualStyleBackColor = true;
            // 
            // ii1
            // 
            this.ii1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ii1.Location = new System.Drawing.Point(803, 563);
            this.ii1.Name = "ii1";
            this.ii1.Size = new System.Drawing.Size(58, 44);
            this.ii1.TabIndex = 150;
            this.ii1.Text = "II1";
            this.ii1.UseVisualStyleBackColor = true;
            // 
            // jj1
            // 
            this.jj1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.jj1.Location = new System.Drawing.Point(803, 613);
            this.jj1.Name = "jj1";
            this.jj1.Size = new System.Drawing.Size(58, 44);
            this.jj1.TabIndex = 149;
            this.jj1.Text = "JJ1";
            this.jj1.UseVisualStyleBackColor = true;
            // 
            // ee2
            // 
            this.ee2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ee2.Location = new System.Drawing.Point(867, 363);
            this.ee2.Name = "ee2";
            this.ee2.Size = new System.Drawing.Size(58, 44);
            this.ee2.TabIndex = 148;
            this.ee2.Text = "EE2";
            this.ee2.UseVisualStyleBackColor = true;
            // 
            // ff2
            // 
            this.ff2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ff2.Location = new System.Drawing.Point(867, 413);
            this.ff2.Name = "ff2";
            this.ff2.Size = new System.Drawing.Size(58, 44);
            this.ff2.TabIndex = 147;
            this.ff2.Text = "FF2";
            this.ff2.UseVisualStyleBackColor = true;
            // 
            // gg2
            // 
            this.gg2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gg2.Location = new System.Drawing.Point(867, 463);
            this.gg2.Name = "gg2";
            this.gg2.Size = new System.Drawing.Size(58, 44);
            this.gg2.TabIndex = 146;
            this.gg2.Text = "GG2";
            this.gg2.UseVisualStyleBackColor = true;
            // 
            // hh2
            // 
            this.hh2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hh2.Location = new System.Drawing.Point(867, 513);
            this.hh2.Name = "hh2";
            this.hh2.Size = new System.Drawing.Size(58, 44);
            this.hh2.TabIndex = 145;
            this.hh2.Text = "HH2";
            this.hh2.UseVisualStyleBackColor = true;
            // 
            // dd1
            // 
            this.dd1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd1.Location = new System.Drawing.Point(803, 313);
            this.dd1.Name = "dd1";
            this.dd1.Size = new System.Drawing.Size(58, 44);
            this.dd1.TabIndex = 144;
            this.dd1.Text = "DD1";
            this.dd1.UseVisualStyleBackColor = true;
            // 
            // dd7
            // 
            this.dd7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd7.Location = new System.Drawing.Point(1187, 313);
            this.dd7.Name = "dd7";
            this.dd7.Size = new System.Drawing.Size(58, 44);
            this.dd7.TabIndex = 143;
            this.dd7.Text = "DD7";
            this.dd7.UseVisualStyleBackColor = true;
            // 
            // dd8
            // 
            this.dd8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd8.Location = new System.Drawing.Point(1251, 313);
            this.dd8.Name = "dd8";
            this.dd8.Size = new System.Drawing.Size(58, 44);
            this.dd8.TabIndex = 142;
            this.dd8.Text = "DD8";
            this.dd8.UseVisualStyleBackColor = true;
            // 
            // dd6
            // 
            this.dd6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd6.Location = new System.Drawing.Point(1123, 313);
            this.dd6.Name = "dd6";
            this.dd6.Size = new System.Drawing.Size(58, 44);
            this.dd6.TabIndex = 141;
            this.dd6.Text = "DD6";
            this.dd6.UseVisualStyleBackColor = true;
            // 
            // dd5
            // 
            this.dd5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd5.Location = new System.Drawing.Point(1059, 313);
            this.dd5.Name = "dd5";
            this.dd5.Size = new System.Drawing.Size(58, 44);
            this.dd5.TabIndex = 140;
            this.dd5.Text = "DD5";
            this.dd5.UseVisualStyleBackColor = true;
            // 
            // dd4
            // 
            this.dd4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd4.Location = new System.Drawing.Point(995, 313);
            this.dd4.Name = "dd4";
            this.dd4.Size = new System.Drawing.Size(58, 44);
            this.dd4.TabIndex = 139;
            this.dd4.Text = "DD4";
            this.dd4.UseVisualStyleBackColor = true;
            // 
            // dd3
            // 
            this.dd3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd3.Location = new System.Drawing.Point(931, 313);
            this.dd3.Name = "dd3";
            this.dd3.Size = new System.Drawing.Size(58, 44);
            this.dd3.TabIndex = 138;
            this.dd3.Text = "DD3";
            this.dd3.UseVisualStyleBackColor = true;
            // 
            // dd2
            // 
            this.dd2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dd2.Location = new System.Drawing.Point(867, 313);
            this.dd2.Name = "dd2";
            this.dd2.Size = new System.Drawing.Size(58, 44);
            this.dd2.TabIndex = 137;
            this.dd2.Text = "DD2";
            this.dd2.UseVisualStyleBackColor = true;
            // 
            // cc1
            // 
            this.cc1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc1.Location = new System.Drawing.Point(803, 263);
            this.cc1.Name = "cc1";
            this.cc1.Size = new System.Drawing.Size(58, 44);
            this.cc1.TabIndex = 136;
            this.cc1.Text = "CC1";
            this.cc1.UseVisualStyleBackColor = true;
            // 
            // cc2
            // 
            this.cc2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc2.Location = new System.Drawing.Point(867, 263);
            this.cc2.Name = "cc2";
            this.cc2.Size = new System.Drawing.Size(58, 44);
            this.cc2.TabIndex = 135;
            this.cc2.Text = "CC2";
            this.cc2.UseVisualStyleBackColor = true;
            // 
            // cc3
            // 
            this.cc3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc3.Location = new System.Drawing.Point(931, 263);
            this.cc3.Name = "cc3";
            this.cc3.Size = new System.Drawing.Size(58, 44);
            this.cc3.TabIndex = 134;
            this.cc3.Text = "CC3";
            this.cc3.UseVisualStyleBackColor = true;
            // 
            // cc4
            // 
            this.cc4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc4.Location = new System.Drawing.Point(995, 263);
            this.cc4.Name = "cc4";
            this.cc4.Size = new System.Drawing.Size(58, 44);
            this.cc4.TabIndex = 133;
            this.cc4.Text = "CC4";
            this.cc4.UseVisualStyleBackColor = true;
            // 
            // cc5
            // 
            this.cc5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc5.Location = new System.Drawing.Point(1059, 263);
            this.cc5.Name = "cc5";
            this.cc5.Size = new System.Drawing.Size(58, 44);
            this.cc5.TabIndex = 132;
            this.cc5.Text = "CC5";
            this.cc5.UseVisualStyleBackColor = true;
            // 
            // cc6
            // 
            this.cc6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc6.Location = new System.Drawing.Point(1123, 263);
            this.cc6.Name = "cc6";
            this.cc6.Size = new System.Drawing.Size(58, 44);
            this.cc6.TabIndex = 131;
            this.cc6.Text = "CC6";
            this.cc6.UseVisualStyleBackColor = true;
            // 
            // cc7
            // 
            this.cc7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc7.Location = new System.Drawing.Point(1187, 263);
            this.cc7.Name = "cc7";
            this.cc7.Size = new System.Drawing.Size(58, 44);
            this.cc7.TabIndex = 130;
            this.cc7.Text = "CC7";
            this.cc7.UseVisualStyleBackColor = true;
            // 
            // cc10
            // 
            this.cc10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc10.Location = new System.Drawing.Point(1379, 263);
            this.cc10.Name = "cc10";
            this.cc10.Size = new System.Drawing.Size(58, 44);
            this.cc10.TabIndex = 129;
            this.cc10.Text = "CC10";
            this.cc10.UseVisualStyleBackColor = true;
            // 
            // cc9
            // 
            this.cc9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc9.Location = new System.Drawing.Point(1315, 263);
            this.cc9.Name = "cc9";
            this.cc9.Size = new System.Drawing.Size(58, 44);
            this.cc9.TabIndex = 128;
            this.cc9.Text = "CC9";
            this.cc9.UseVisualStyleBackColor = true;
            // 
            // cc8
            // 
            this.cc8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cc8.Location = new System.Drawing.Point(1251, 263);
            this.cc8.Name = "cc8";
            this.cc8.Size = new System.Drawing.Size(58, 44);
            this.cc8.TabIndex = 127;
            this.cc8.Text = "CC8";
            this.cc8.UseVisualStyleBackColor = true;
            // 
            // bb4
            // 
            this.bb4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb4.Location = new System.Drawing.Point(995, 213);
            this.bb4.Name = "bb4";
            this.bb4.Size = new System.Drawing.Size(58, 44);
            this.bb4.TabIndex = 126;
            this.bb4.Text = "BB4";
            this.bb4.UseVisualStyleBackColor = true;
            // 
            // bb5
            // 
            this.bb5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb5.Location = new System.Drawing.Point(1059, 213);
            this.bb5.Name = "bb5";
            this.bb5.Size = new System.Drawing.Size(58, 44);
            this.bb5.TabIndex = 125;
            this.bb5.Text = "BB5";
            this.bb5.UseVisualStyleBackColor = true;
            // 
            // bb6
            // 
            this.bb6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb6.Location = new System.Drawing.Point(1123, 213);
            this.bb6.Name = "bb6";
            this.bb6.Size = new System.Drawing.Size(58, 44);
            this.bb6.TabIndex = 124;
            this.bb6.Text = "BB6";
            this.bb6.UseVisualStyleBackColor = true;
            // 
            // bb7
            // 
            this.bb7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb7.Location = new System.Drawing.Point(1187, 213);
            this.bb7.Name = "bb7";
            this.bb7.Size = new System.Drawing.Size(58, 44);
            this.bb7.TabIndex = 123;
            this.bb7.Text = "BB7";
            this.bb7.UseVisualStyleBackColor = true;
            // 
            // bb8
            // 
            this.bb8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb8.Location = new System.Drawing.Point(1251, 213);
            this.bb8.Name = "bb8";
            this.bb8.Size = new System.Drawing.Size(58, 44);
            this.bb8.TabIndex = 122;
            this.bb8.Text = "BB8";
            this.bb8.UseVisualStyleBackColor = true;
            // 
            // bb9
            // 
            this.bb9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb9.Location = new System.Drawing.Point(1315, 213);
            this.bb9.Name = "bb9";
            this.bb9.Size = new System.Drawing.Size(58, 44);
            this.bb9.TabIndex = 121;
            this.bb9.Text = "BB9";
            this.bb9.UseVisualStyleBackColor = true;
            // 
            // bb10
            // 
            this.bb10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb10.Location = new System.Drawing.Point(1379, 213);
            this.bb10.Name = "bb10";
            this.bb10.Size = new System.Drawing.Size(58, 44);
            this.bb10.TabIndex = 120;
            this.bb10.Text = "BB10";
            this.bb10.UseVisualStyleBackColor = true;
            // 
            // aa2
            // 
            this.aa2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa2.Location = new System.Drawing.Point(867, 163);
            this.aa2.Name = "aa2";
            this.aa2.Size = new System.Drawing.Size(58, 44);
            this.aa2.TabIndex = 119;
            this.aa2.Text = "AA2";
            this.aa2.UseVisualStyleBackColor = true;
            // 
            // aa3
            // 
            this.aa3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa3.Location = new System.Drawing.Point(931, 163);
            this.aa3.Name = "aa3";
            this.aa3.Size = new System.Drawing.Size(58, 44);
            this.aa3.TabIndex = 118;
            this.aa3.Text = "AA3";
            this.aa3.UseVisualStyleBackColor = true;
            // 
            // aa4
            // 
            this.aa4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa4.Location = new System.Drawing.Point(995, 163);
            this.aa4.Name = "aa4";
            this.aa4.Size = new System.Drawing.Size(58, 44);
            this.aa4.TabIndex = 117;
            this.aa4.Text = "AA4";
            this.aa4.UseVisualStyleBackColor = true;
            // 
            // aa5
            // 
            this.aa5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa5.Location = new System.Drawing.Point(1059, 163);
            this.aa5.Name = "aa5";
            this.aa5.Size = new System.Drawing.Size(58, 44);
            this.aa5.TabIndex = 116;
            this.aa5.Text = "AA5";
            this.aa5.UseVisualStyleBackColor = true;
            // 
            // aa6
            // 
            this.aa6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa6.Location = new System.Drawing.Point(1123, 163);
            this.aa6.Name = "aa6";
            this.aa6.Size = new System.Drawing.Size(58, 44);
            this.aa6.TabIndex = 115;
            this.aa6.Text = "AA6";
            this.aa6.UseVisualStyleBackColor = true;
            // 
            // aa7
            // 
            this.aa7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa7.Location = new System.Drawing.Point(1187, 163);
            this.aa7.Name = "aa7";
            this.aa7.Size = new System.Drawing.Size(58, 44);
            this.aa7.TabIndex = 114;
            this.aa7.Text = "AA7";
            this.aa7.UseVisualStyleBackColor = true;
            // 
            // aa8
            // 
            this.aa8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa8.Location = new System.Drawing.Point(1251, 163);
            this.aa8.Name = "aa8";
            this.aa8.Size = new System.Drawing.Size(58, 44);
            this.aa8.TabIndex = 113;
            this.aa8.Text = "AA8";
            this.aa8.UseVisualStyleBackColor = true;
            // 
            // aa9
            // 
            this.aa9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa9.Location = new System.Drawing.Point(1315, 163);
            this.aa9.Name = "aa9";
            this.aa9.Size = new System.Drawing.Size(58, 44);
            this.aa9.TabIndex = 112;
            this.aa9.Text = "AA9";
            this.aa9.UseVisualStyleBackColor = true;
            // 
            // aa10
            // 
            this.aa10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa10.Location = new System.Drawing.Point(1379, 163);
            this.aa10.Name = "aa10";
            this.aa10.Size = new System.Drawing.Size(58, 44);
            this.aa10.TabIndex = 111;
            this.aa10.Text = "AA10";
            this.aa10.UseVisualStyleBackColor = true;
            // 
            // bb2
            // 
            this.bb2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb2.Location = new System.Drawing.Point(867, 213);
            this.bb2.Name = "bb2";
            this.bb2.Size = new System.Drawing.Size(58, 44);
            this.bb2.TabIndex = 110;
            this.bb2.Text = "BB2";
            this.bb2.UseVisualStyleBackColor = true;
            // 
            // bb1
            // 
            this.bb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb1.Location = new System.Drawing.Point(803, 213);
            this.bb1.Name = "bb1";
            this.bb1.Size = new System.Drawing.Size(58, 44);
            this.bb1.TabIndex = 109;
            this.bb1.Text = "BB1";
            this.bb1.UseVisualStyleBackColor = true;
            // 
            // bb3
            // 
            this.bb3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bb3.Location = new System.Drawing.Point(931, 213);
            this.bb3.Name = "bb3";
            this.bb3.Size = new System.Drawing.Size(58, 44);
            this.bb3.TabIndex = 108;
            this.bb3.Text = "BB3";
            this.bb3.UseVisualStyleBackColor = true;
            // 
            // aa1
            // 
            this.aa1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.aa1.Location = new System.Drawing.Point(803, 163);
            this.aa1.Name = "aa1";
            this.aa1.Size = new System.Drawing.Size(58, 44);
            this.aa1.TabIndex = 107;
            this.aa1.Text = "AA1";
            this.aa1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(70, 129);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 31);
            this.label5.TabIndex = 207;
            this.label5.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(133, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 31);
            this.label6.TabIndex = 208;
            this.label6.Text = "2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(197, 129);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 31);
            this.label7.TabIndex = 209;
            this.label7.Text = "3";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(260, 129);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 31);
            this.label8.TabIndex = 210;
            this.label8.Text = "4";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(455, 129);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 31);
            this.label9.TabIndex = 211;
            this.label9.Text = "7";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(390, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 31);
            this.label10.TabIndex = 212;
            this.label10.Text = "6";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(325, 129);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 31);
            this.label11.TabIndex = 213;
            this.label11.Text = "5";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(643, 129);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 31);
            this.label12.TabIndex = 214;
            this.label12.Text = "10";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(582, 129);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(26, 31);
            this.label13.TabIndex = 215;
            this.label13.Text = "9";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(518, 129);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 31);
            this.label14.TabIndex = 216;
            this.label14.Text = "8";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(1269, 129);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(26, 31);
            this.label15.TabIndex = 226;
            this.label15.Text = "8";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(1333, 129);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 31);
            this.label16.TabIndex = 225;
            this.label16.Text = "9";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(1394, 129);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(38, 31);
            this.label17.TabIndex = 224;
            this.label17.Text = "10";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(1076, 129);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(26, 31);
            this.label18.TabIndex = 223;
            this.label18.Text = "5";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(1141, 129);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(26, 31);
            this.label19.TabIndex = 222;
            this.label19.Text = "6";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(1206, 129);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(26, 31);
            this.label20.TabIndex = 221;
            this.label20.Text = "7";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(1011, 129);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(26, 31);
            this.label21.TabIndex = 220;
            this.label21.Text = "4";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(948, 129);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(26, 31);
            this.label22.TabIndex = 219;
            this.label22.Text = "3";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label23.Location = new System.Drawing.Point(884, 129);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 31);
            this.label23.TabIndex = 218;
            this.label23.Text = "2";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(821, 129);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(26, 31);
            this.label24.TabIndex = 217;
            this.label24.Text = "1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(21, 513);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(30, 31);
            this.label25.TabIndex = 227;
            this.label25.Text = "H";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(21, 463);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(30, 31);
            this.label26.TabIndex = 228;
            this.label26.Text = "G";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(21, 416);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(25, 31);
            this.label27.TabIndex = 229;
            this.label27.Text = "F";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(21, 366);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 31);
            this.label28.TabIndex = 230;
            this.label28.Text = "E";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(16, 316);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(30, 31);
            this.label29.TabIndex = 231;
            this.label29.Text = "D";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(15, 266);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(28, 31);
            this.label30.TabIndex = 232;
            this.label30.Text = "C";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label31.Location = new System.Drawing.Point(21, 216);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(27, 31);
            this.label31.TabIndex = 233;
            this.label31.Text = "B";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label32.Location = new System.Drawing.Point(21, 166);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(29, 31);
            this.label32.TabIndex = 234;
            this.label32.Text = "A";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(21, 616);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(22, 31);
            this.label33.TabIndex = 235;
            this.label33.Text = "J";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(21, 563);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(20, 31);
            this.label34.TabIndex = 236;
            this.label34.Text = "I";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.Transparent;
            this.label35.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(758, 563);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(26, 31);
            this.label35.TabIndex = 246;
            this.label35.Text = "II";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(755, 613);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 31);
            this.label36.TabIndex = 245;
            this.label36.Text = "JJ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label37.Location = new System.Drawing.Point(752, 166);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(44, 31);
            this.label37.TabIndex = 244;
            this.label37.Text = "AA";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label38.Location = new System.Drawing.Point(752, 216);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(40, 31);
            this.label38.TabIndex = 243;
            this.label38.Text = "BB";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label39.Location = new System.Drawing.Point(751, 266);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 31);
            this.label39.TabIndex = 242;
            this.label39.Text = "CC";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label40.Location = new System.Drawing.Point(746, 316);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(46, 31);
            this.label40.TabIndex = 241;
            this.label40.Text = "DD";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label41.Location = new System.Drawing.Point(746, 366);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(38, 31);
            this.label41.TabIndex = 240;
            this.label41.Text = "EE";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label42.Location = new System.Drawing.Point(746, 413);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(36, 31);
            this.label42.TabIndex = 239;
            this.label42.Text = "FF";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label43.Location = new System.Drawing.Point(746, 466);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(46, 31);
            this.label43.TabIndex = 238;
            this.label43.Text = "GG";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(746, 513);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(46, 31);
            this.label44.TabIndex = 237;
            this.label44.Text = "HH";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label46.Location = new System.Drawing.Point(433, 83);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(47, 40);
            this.label46.TabIndex = 248;
            this.label46.Text = "00";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Transparent;
            this.label47.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label47.Location = new System.Drawing.Point(1251, 83);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(47, 40);
            this.label47.TabIndex = 249;
            this.label47.Text = "00";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label45.Location = new System.Drawing.Point(1076, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(52, 40);
            this.label45.TabIndex = 250;
            this.label45.Text = "A1";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.Transparent;
            this.label48.Font = new System.Drawing.Font("Arial Narrow", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label48.Location = new System.Drawing.Point(674, 59);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(152, 40);
            this.label48.TabIndex = 251;
            this.label48.Text = "Round: 50";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::battleshipp.Properties.Resources.wallpaper1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1447, 673);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dd10);
            this.Controls.Add(this.ee10);
            this.Controls.Add(this.ee9);
            this.Controls.Add(this.ff10);
            this.Controls.Add(this.dd9);
            this.Controls.Add(this.ii9);
            this.Controls.Add(this.ii10);
            this.Controls.Add(this.hh9);
            this.Controls.Add(this.hh10);
            this.Controls.Add(this.gg9);
            this.Controls.Add(this.gg10);
            this.Controls.Add(this.ff9);
            this.Controls.Add(this.jj7);
            this.Controls.Add(this.ee8);
            this.Controls.Add(this.ff8);
            this.Controls.Add(this.gg8);
            this.Controls.Add(this.hh8);
            this.Controls.Add(this.ii8);
            this.Controls.Add(this.jj8);
            this.Controls.Add(this.jj9);
            this.Controls.Add(this.jj10);
            this.Controls.Add(this.ii6);
            this.Controls.Add(this.jj6);
            this.Controls.Add(this.ee7);
            this.Controls.Add(this.ff7);
            this.Controls.Add(this.gg7);
            this.Controls.Add(this.hh7);
            this.Controls.Add(this.ii7);
            this.Controls.Add(this.ii4);
            this.Controls.Add(this.jj4);
            this.Controls.Add(this.ee5);
            this.Controls.Add(this.ff5);
            this.Controls.Add(this.gg5);
            this.Controls.Add(this.hh5);
            this.Controls.Add(this.ii5);
            this.Controls.Add(this.jj5);
            this.Controls.Add(this.ee6);
            this.Controls.Add(this.ff6);
            this.Controls.Add(this.gg6);
            this.Controls.Add(this.hh6);
            this.Controls.Add(this.gg3);
            this.Controls.Add(this.hh3);
            this.Controls.Add(this.ii3);
            this.Controls.Add(this.jj3);
            this.Controls.Add(this.ee4);
            this.Controls.Add(this.ff4);
            this.Controls.Add(this.gg4);
            this.Controls.Add(this.hh4);
            this.Controls.Add(this.ii2);
            this.Controls.Add(this.jj2);
            this.Controls.Add(this.ee3);
            this.Controls.Add(this.ff3);
            this.Controls.Add(this.ee1);
            this.Controls.Add(this.ff1);
            this.Controls.Add(this.gg1);
            this.Controls.Add(this.hh1);
            this.Controls.Add(this.ii1);
            this.Controls.Add(this.jj1);
            this.Controls.Add(this.ee2);
            this.Controls.Add(this.ff2);
            this.Controls.Add(this.gg2);
            this.Controls.Add(this.hh2);
            this.Controls.Add(this.dd1);
            this.Controls.Add(this.dd7);
            this.Controls.Add(this.dd8);
            this.Controls.Add(this.dd6);
            this.Controls.Add(this.dd5);
            this.Controls.Add(this.dd4);
            this.Controls.Add(this.dd3);
            this.Controls.Add(this.dd2);
            this.Controls.Add(this.cc1);
            this.Controls.Add(this.cc2);
            this.Controls.Add(this.cc3);
            this.Controls.Add(this.cc4);
            this.Controls.Add(this.cc5);
            this.Controls.Add(this.cc6);
            this.Controls.Add(this.cc7);
            this.Controls.Add(this.cc10);
            this.Controls.Add(this.cc9);
            this.Controls.Add(this.cc8);
            this.Controls.Add(this.bb4);
            this.Controls.Add(this.bb5);
            this.Controls.Add(this.bb6);
            this.Controls.Add(this.bb7);
            this.Controls.Add(this.bb8);
            this.Controls.Add(this.bb9);
            this.Controls.Add(this.bb10);
            this.Controls.Add(this.aa2);
            this.Controls.Add(this.aa3);
            this.Controls.Add(this.aa4);
            this.Controls.Add(this.aa5);
            this.Controls.Add(this.aa6);
            this.Controls.Add(this.aa7);
            this.Controls.Add(this.aa8);
            this.Controls.Add(this.aa9);
            this.Controls.Add(this.aa10);
            this.Controls.Add(this.bb2);
            this.Controls.Add(this.bb1);
            this.Controls.Add(this.bb3);
            this.Controls.Add(this.aa1);
            this.Controls.Add(this.d10);
            this.Controls.Add(this.e10);
            this.Controls.Add(this.e9);
            this.Controls.Add(this.f10);
            this.Controls.Add(this.d9);
            this.Controls.Add(this.i9);
            this.Controls.Add(this.i10);
            this.Controls.Add(this.h9);
            this.Controls.Add(this.h10);
            this.Controls.Add(this.g9);
            this.Controls.Add(this.g10);
            this.Controls.Add(this.f9);
            this.Controls.Add(this.j7);
            this.Controls.Add(this.e8);
            this.Controls.Add(this.f8);
            this.Controls.Add(this.g8);
            this.Controls.Add(this.h8);
            this.Controls.Add(this.i8);
            this.Controls.Add(this.j8);
            this.Controls.Add(this.j9);
            this.Controls.Add(this.j10);
            this.Controls.Add(this.i6);
            this.Controls.Add(this.j6);
            this.Controls.Add(this.e7);
            this.Controls.Add(this.f7);
            this.Controls.Add(this.g7);
            this.Controls.Add(this.h7);
            this.Controls.Add(this.i7);
            this.Controls.Add(this.i4);
            this.Controls.Add(this.j4);
            this.Controls.Add(this.e5);
            this.Controls.Add(this.f5);
            this.Controls.Add(this.g5);
            this.Controls.Add(this.h5);
            this.Controls.Add(this.i5);
            this.Controls.Add(this.j5);
            this.Controls.Add(this.e6);
            this.Controls.Add(this.f6);
            this.Controls.Add(this.g6);
            this.Controls.Add(this.h6);
            this.Controls.Add(this.g3);
            this.Controls.Add(this.h3);
            this.Controls.Add(this.i3);
            this.Controls.Add(this.j3);
            this.Controls.Add(this.e4);
            this.Controls.Add(this.f4);
            this.Controls.Add(this.g4);
            this.Controls.Add(this.h4);
            this.Controls.Add(this.i2);
            this.Controls.Add(this.j2);
            this.Controls.Add(this.e3);
            this.Controls.Add(this.f3);
            this.Controls.Add(this.e1);
            this.Controls.Add(this.f1);
            this.Controls.Add(this.g1);
            this.Controls.Add(this.h1);
            this.Controls.Add(this.i1);
            this.Controls.Add(this.j1);
            this.Controls.Add(this.e2);
            this.Controls.Add(this.f2);
            this.Controls.Add(this.g2);
            this.Controls.Add(this.h2);
            this.Controls.Add(this.d1);
            this.Controls.Add(this.d7);
            this.Controls.Add(this.d8);
            this.Controls.Add(this.d6);
            this.Controls.Add(this.d5);
            this.Controls.Add(this.d4);
            this.Controls.Add(this.d3);
            this.Controls.Add(this.d2);
            this.Controls.Add(this.c1);
            this.Controls.Add(this.c2);
            this.Controls.Add(this.c3);
            this.Controls.Add(this.c4);
            this.Controls.Add(this.c5);
            this.Controls.Add(this.c6);
            this.Controls.Add(this.c7);
            this.Controls.Add(this.c10);
            this.Controls.Add(this.c9);
            this.Controls.Add(this.c8);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b10);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.a3);
            this.Controls.Add(this.a4);
            this.Controls.Add(this.a5);
            this.Controls.Add(this.a6);
            this.Controls.Add(this.a7);
            this.Controls.Add(this.a8);
            this.Controls.Add(this.a9);
            this.Controls.Add(this.a10);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.a1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox comboBox1;
        private Button button1;
        private Button a1;
        private Button b3;
        private Button b1;
        private Button b2;
        private Button a10;
        private Button a9;
        private Button a8;
        private Button a7;
        private Button a6;
        private Button a5;
        private Button a4;
        private Button a3;
        private Button a2;
        private Button b10;
        private Button b9;
        private Button b8;
        private Button b7;
        private Button b6;
        private Button b5;
        private Button b4;
        private Button c8;
        private Button c9;
        private Button c10;
        private Button c7;
        private Button c6;
        private Button c5;
        private Button c4;
        private Button c3;
        private Button c2;
        private Button c1;
        private Button d2;
        private Button d3;
        private Button d4;
        private Button d5;
        private Button d6;
        private Button d8;
        private Button d7;
        private Button d1;
        private Button h2;
        private Button g2;
        private Button f2;
        private Button e2;
        private Button j1;
        private Button i1;
        private Button h1;
        private Button g1;
        private Button f1;
        private Button e1;
        private Button f3;
        private Button e3;
        private Button j2;
        private Button i2;
        private Button h4;
        private Button g4;
        private Button f4;
        private Button e4;
        private Button j3;
        private Button i3;
        private Button h3;
        private Button g3;
        private Button h6;
        private Button g6;
        private Button f6;
        private Button e6;
        private Button j5;
        private Button i5;
        private Button h5;
        private Button g5;
        private Button f5;
        private Button e5;
        private Button j4;
        private Button i4;
        private Button i7;
        private Button h7;
        private Button g7;
        private Button f7;
        private Button e7;
        private Button j6;
        private Button i6;
        private Button j10;
        private Button j9;
        private Button j8;
        private Button i8;
        private Button h8;
        private Button g8;
        private Button f8;
        private Button e8;
        private Button j7;
        private Button f9;
        private Button g10;
        private Button g9;
        private Button h10;
        private Button h9;
        private Button i10;
        private Button i9;
        private Button d9;
        private Button f10;
        private Button e9;
        private Button e10;
        private Button d10;
        private Button dd10;
        private Button ee10;
        private Button ee9;
        private Button ff10;
        private Button dd9;
        private Button ii9;
        private Button ii10;
        private Button hh9;
        private Button hh10;
        private Button gg9;
        private Button gg10;
        private Button ff9;
        private Button jj7;
        private Button ee8;
        private Button ff8;
        private Button gg8;
        private Button hh8;
        private Button ii8;
        private Button jj8;
        private Button jj9;
        private Button jj10;
        private Button ii6;
        private Button jj6;
        private Button ee7;
        private Button ff7;
        private Button gg7;
        private Button hh7;
        private Button ii7;
        private Button ii4;
        private Button jj4;
        private Button ee5;
        private Button ff5;
        private Button gg5;
        private Button hh5;
        private Button ii5;
        private Button jj5;
        private Button ee6;
        private Button ff6;
        private Button gg6;
        private Button hh6;
        private Button gg3;
        private Button hh3;
        private Button ii3;
        private Button jj3;
        private Button ee4;
        private Button ff4;
        private Button gg4;
        private Button hh4;
        private Button ii2;
        private Button jj2;
        private Button ee3;
        private Button ff3;
        private Button ee1;
        private Button ff1;
        private Button gg1;
        private Button hh1;
        private Button ii1;
        private Button jj1;
        private Button ee2;
        private Button ff2;
        private Button gg2;
        private Button hh2;
        private Button dd1;
        private Button dd7;
        private Button dd8;
        private Button dd6;
        private Button dd5;
        private Button dd4;
        private Button dd3;
        private Button dd2;
        private Button cc1;
        private Button cc2;
        private Button cc3;
        private Button cc4;
        private Button cc5;
        private Button cc6;
        private Button cc7;
        private Button cc10;
        private Button cc9;
        private Button cc8;
        private Button bb4;
        private Button bb5;
        private Button bb6;
        private Button bb7;
        private Button bb8;
        private Button bb9;
        private Button bb10;
        private Button aa2;
        private Button aa3;
        private Button aa4;
        private Button aa5;
        private Button aa6;
        private Button aa7;
        private Button aa8;
        private Button aa9;
        private Button aa10;
        private Button bb2;
        private Button bb1;
        private Button bb3;
        private Button aa1;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private Label label27;
        private Label label28;
        private Label label29;
        private Label label30;
        private Label label31;
        private Label label32;
        private Label label33;
        private Label label34;
        private Label label35;
        private Label label36;
        private Label label37;
        private Label label38;
        private Label label39;
        private Label label40;
        private Label label41;
        private Label label42;
        private Label label43;
        private Label label44;
        private System.Windows.Forms.Timer timer1;
        private Label label46;
        private Label label47;
        private Label label45;
        private Label label48;
    }
}