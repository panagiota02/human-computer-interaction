﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace slotss
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String connectionString = "Data source=C:\\Users\\Lenovo\\OneDrive\\Desktop\\slotss\\slotss\\bin\\Debug\\players.db;";
            SQLiteConnection conn = new SQLiteConnection(connectionString);
            conn.Open();
            String selectSQL = "Select * from players";
            SQLiteCommand cmd = new SQLiteCommand(selectSQL, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();
            StringBuilder builder = new StringBuilder();
            while (reader.Read())
            {
                builder.Append(reader.GetString(0));
                builder.Append(Environment.NewLine);
                int p;
                p = reader.GetInt32(1);
                builder.Append(p.ToString());
                builder.Append(Environment.NewLine+"------------------------------------------------------");
                builder.Append(Environment.NewLine);
            }
            conn.Close();
            richTextBox1.Text = builder.ToString();
        }
    }
}
