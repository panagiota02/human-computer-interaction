﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace slotss
{
    public partial class Form5 : Form
    {
        public static int sp;
        public Form5()
        {
            InitializeComponent();
        }
        public string LabelText
        {
            get
            {
                return this.label10.Text;
            }
            set
            {
                this.label10.Text = value;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 a1 = new Form3();
            a1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 a1 = new Form4();
            a1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (sp == 0)
            {
                label10.Text = "Better luck next time " + Environment.NewLine + "Coins earned: " + LabelText;
                
            }
        }
    }
}
