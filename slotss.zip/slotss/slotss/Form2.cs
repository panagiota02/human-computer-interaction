﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SQLite;

namespace slotss
{
    public partial class Form2 : Form
    {

        public Form2()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String connectionString = "Data source=C:\\Users\\Lenovo\\OneDrive\\Desktop\\slotss\\slotss\\bin\\Debug\\players.db;";
            SQLiteConnection conn = new SQLiteConnection(connectionString);
            conn.Open();
            string insertSQL = "Insert into players (Username,Coins) values('" + textBox1.Text + "','" + textBox3.Text + "')";
            SQLiteCommand cmd = new SQLiteCommand(insertSQL, conn);
            cmd.ExecuteNonQuery();
            int y = int.Parse(textBox3.Text);
            int x = Int32.Parse(textBox2.Text);     //metatropi apo string se int
            if (x > 2 && x < 6)
            {
                this.Hide();
                Form3.message = textBox3.Text;
                Form3.com = x;
                Form3 a2 = new Form3();
                a2.ShowDialog();
            }
              
             else
                 MessageBox.Show("BETWEEN 3 AND 5!!");
        }
    }
}

