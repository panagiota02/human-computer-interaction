﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace slotss
{
    public partial class Form3 : Form
    {
        public static string message;
        public static int com;
        public static int r;
        public static int sp;
        public Form3()
        {
            InitializeComponent();
            label4.Text = message;
            r = com;
        }
        int y = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;
           
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            pictureBox10.Visible = false;
            pictureBox11.Visible = false;
            pictureBox12.Visible = false;
            pictureBox13.Visible = false;
            pictureBox14.Visible = false;
            pictureBox15.Visible = false;
            label5.Visible = false; 
            label12.Visible = false; 
            label3.Visible = false;



        }
        int total = 1;
        private void timer1_Tick(object sender, EventArgs e)
        {
            string[] paths = Directory.GetFiles(@"C:\Users\Lenovo\OneDrive\Desktop\slotss\slotss\bin\Debug", "*.png");
            List<string> images = paths.ToList();
            string sigkr;
            int c = 0;
            
            for (int i = 1; i <= r; i++)
            {
                Random random = new Random();
                PictureBox pb = new PictureBox();
                pb.SizeMode = PictureBoxSizeMode.StretchImage;
                pb.Size = new Size(170, 170);
                pb.Location = new Point(190 * y, 200);
                pb.Name = i.ToString();
                pb.Tag = "eikona" + i.ToString();
                pb.ImageLocation = paths[random.Next(0, 13)];
                y++;
                Controls.Add(pb);
                sigkr = "eikona" + i.ToString();
                c++;
                Comp(i, sigkr, c);
            }
            button1.Enabled = false;
            timer1.Enabled = false;
            
            
        }
        
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 a1 = new Form4();
            a1.ShowDialog();
        }

        private void Comp(int i ,string sigkr,int c)
        {

            string thesi1 = " ";
            string thesi2 = " ";
            string thesi3 = " ";
            string thesi4 = " ";
            string thesi5 = " ";

            if (i == 1)         //columns
            {
                thesi1 = sigkr;
            }
            else if (i == 2)
            {
                thesi2 = sigkr;
            }
            else if (i == 3)
            {
                thesi3 = sigkr;
            }
            else if (i == 4)
            {
                thesi4 = sigkr;
            }
            else if (i == 5)
            {
                thesi5 = sigkr;
            }
            
            if (c == 3)
            {
                if (thesi1 == thesi2 && thesi2 == thesi3)
                {
                    Bitmap3(thesi1, thesi2, thesi3);
                    timer2.Enabled = false;
                }
                else
                {
                    timer2.Enabled = false;
                }
            }

            if (c == 4)
            {
                if (thesi1 == thesi2 && thesi2 == thesi3 && thesi3 == thesi4)
                {
                    Bitmap4(thesi1, thesi2, thesi3, thesi4);
                    timer2.Enabled = false;
                }
                else
                {
                    timer2.Enabled = false;
                }
            }

            if (c == 5)
            {
                if (thesi1 == thesi2 && thesi2 == thesi3 && thesi3 == thesi4 && thesi4 == thesi5)
                {
                    Bitmap5(thesi1, thesi2, thesi3, thesi4, thesi5);
                    timer2.Enabled = false;
                }
                else
                {
                    
                    timer2.Enabled = false;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            
        }

        private void Bitmap5(string thesi1, string thesi2, string thesi3, string thesi4, string thesi5)
        {
            int p = y;
            int sp;
           /* Bitmap eikona1 = slotss.Properties.Resources.arceus;
            Bitmap eikona3 = slotss.Properties.Resources.darkrai;
            Bitmap eikona4 = slotss.Properties.Resources.darkraizoomed;
            Bitmap eikona2 = slotss.Properties.Resources.rayquaza;
            Bitmap eikona5 = slotss.Properties.Resources.dragapult;
            Bitmap eikona7 = slotss.Properties.Resources.pikachu;
            Bitmap eikona6 = slotss.Properties.Resources.piplup;*/

            if (thesi1 == "eikona1" && thesi2 == "eikona1" && thesi3 == "eikona1" && thesi4 == "eikona1" && thesi5 == "eikona1")
            {
                sp = p * 10000;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

                
            }
            else if (thesi1 == "eikona2" && thesi2 == "eikona2" && thesi3 == "eikona2" && thesi4 == "eikona2" && thesi5 == "eikona2")
            {
                sp = p * 2500;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == "eikona3" && thesi2 == "eikona3" && thesi3 == "eikona3" && thesi4 == "eikona3" && thesi5 == "eikona3")
            {
                sp = p * 500;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == "eikona4" && thesi2 == "eikona4" && thesi3 == "eikona4" && thesi4 == "eikona4" && thesi5 == "eikona4")
            {
                sp = p * 100;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == "eikona5" && thesi2 == "eikona5" && thesi3 == "eikona5" && thesi4 == "eikona5" && thesi5 == "eikona5")
            {
                sp = p * 25;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == "eikona6" && thesi2 == "eikona6" && thesi3 == "eikona6" && thesi4 == "eikona6" && thesi5 == "eikona6")
            {
                sp = p * 10;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();
            }
            else { 
                sp = p * 0;
                label5.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();
            }

        }

        private void Bitmap4(string thesi1, string thesi2, string thesi3, string thesi4)
        {
            int p = y;
            int sp;
            /* Bitmap eikona1 = slotss.Properties.Resources.arceus;
             Bitmap eikona3 = slotss.Properties.Resources.darkrai;
             Bitmap eikona4 = slotss.Properties.Resources.darkraizoomed;
             Bitmap eikona2 = slotss.Properties.Resources.rayquaza;
             Bitmap eikona5 = slotss.Properties.Resources.dragapult;
             Bitmap eikona7 = slotss.Properties.Resources.pikachu;
             Bitmap eikona6 = slotss.Properties.Resources.piplup;*/

            if (thesi1 == pictureBox10.Tag && thesi2 == pictureBox10.Tag && thesi3 == pictureBox10.Tag && thesi4 == pictureBox10.Tag)
            {
                sp = p * 10000;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();


            }
            else if (thesi1 == pictureBox11.Tag && thesi2 == pictureBox11.Tag && thesi3 == pictureBox11.Tag && thesi4 == pictureBox11.Tag)
            {
                sp = p * 2500;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == pictureBox12.Tag && thesi2 == pictureBox12.Tag && thesi3 == pictureBox12.Tag && thesi4 == pictureBox12.Tag)
            {
                sp = p * 500;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == pictureBox13.Tag && thesi2 == pictureBox13.Tag && thesi3 == pictureBox13.Tag && thesi4 == pictureBox13.Tag)
            {
                sp = p * 100;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == pictureBox14.Tag && thesi2 == pictureBox14.Tag && thesi3 == pictureBox14.Tag && thesi4 == pictureBox14.Tag)
            {
                sp = p * 25;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == pictureBox15.Tag && thesi2 == pictureBox15.Tag && thesi3 == pictureBox15.Tag && thesi4 == pictureBox15.Tag)
            {
                sp = p * 10;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();
            }
            else
            {
                sp = p * 0;
                label5.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();
            }

        }

        private void Bitmap3(string thesi1, string thesi2, string thesi3)
        {
            int p = y;
            int sp;
            /* Bitmap eikona1 = slotss.Properties.Resources.arceus;
             Bitmap eikona3 = slotss.Properties.Resources.darkrai;
             Bitmap eikona4 = slotss.Properties.Resources.darkraizoomed;
             Bitmap eikona2 = slotss.Properties.Resources.rayquaza;
             Bitmap eikona5 = slotss.Properties.Resources.dragapult;
             Bitmap eikona7 = slotss.Properties.Resources.pikachu;
             Bitmap eikona6 = slotss.Properties.Resources.piplup;*/

            if (thesi1 == pictureBox10.Tag && thesi2 == pictureBox10.Tag && thesi3 == pictureBox10.Tag)
            {
                sp = p * 10000;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();


            }
            else if (thesi1 == pictureBox11.Tag && thesi2 == pictureBox11.Tag && thesi3 == pictureBox11.Tag)
            {
                sp = p * 2500;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == pictureBox12.Tag && thesi2 == pictureBox12.Tag && thesi3 == pictureBox12.Tag)
            {
                sp = p * 500;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == pictureBox13.Tag && thesi2 == pictureBox13.Tag && thesi3 == pictureBox13.Tag)
            {
                sp = p * 100;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == pictureBox14.Tag && thesi2 == pictureBox14.Tag && thesi3 == pictureBox14.Tag)
            {
                sp = p * 25;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();

            }
            else if (thesi1 == pictureBox15.Tag && thesi2 == pictureBox15.Tag && thesi3 == pictureBox15.Tag)
            {
                sp = p * 10;
                label12.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();
            }
            else
            {
                sp = p * 0;
                label5.Visible = true;
                label3.Visible = true;
                label3.Text = sp.ToString();
            }

        }
        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
